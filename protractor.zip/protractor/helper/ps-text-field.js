/**
 * @file       ps-text-field.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Списки параметров для компонента psTextField
 *
 * @created    [06.11.2015] Lilia Sapurina.
 */

// Идентификатор компонента psTextField на форме
global.psTextFieldCss = "body > form > div";
