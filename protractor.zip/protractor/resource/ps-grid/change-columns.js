/**
 * @file       ps-grid_change_columns.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что есть возможность перемещать колонки, сосед при этом перемещается верно
 *
 * @created    [03.08.2015] Lilia Sapurina.
 */

describe('ps-grid_change_columns', function () {

  var config = browser.params;

  // Глобальные переменные
  var columns_xpath = config.columns_xpath;
  var column_number = config.column_number;
  var move_column_number = config.move_column_number;
  var move_direction = config.move_direction_grid;
  var column_text_css = config.column_text_css;

  // Поиск по локатору
  var all_columns = element.all(by.xpath(columns_xpath));
  var current_column = all_columns.get(column_number - 1);

  var future_column_number = column_number + move_direction * move_column_number;
  var future_column = all_columns.get(future_column_number - 1);

  beforeEach(function(){
    browser.get('sbms/shell.html?shell_login=CMS_HAS&shell_password=qwerty&shell_modus=t&shell_modus=c');
    browser.executeScript("icms.go('WEB_INQ_PROC', 'InquiryList', null, 0)");
  });

  it('перемещение колонок местами должно быть верным', function () {

    count_of_columns = all_columns.count();

    var current_column_text = current_column.element(by.css(column_text_css)).getText();
    var future_column_text = future_column.element(by.css(column_text_css)).getText();

    var current_column_height = 0;
    var current_column_width = 0;
    current_column.getSize().then(function (navDivSize) {
      current_column_height = navDivSize.height;
      current_column_width = navDivSize.width;

      var current_column_x = 0;
      var current_column_y = 0;

      current_column.getLocation().then(function (navDivLocation) {
        current_column_x = navDivLocation.x;
        current_column_y = navDivLocation.y;

        // Перемещаем колонку в зависимости от параметра move_direction вправо или влево
        browser.actions().
                dragAndDrop(current_column, {x: current_column_width * move_column_number * move_direction, y: 0}).
                perform();
      });
    });

    if (move_direction == 1) {
      // Нумерация в массивах начинается с 0, поэтому дополнительно вычитаем 1
      var next_future_column_text1 = all_columns.get(future_column_number
              - 2).element(by.css(column_text_css)).getText();
      expect(next_future_column_text1).toEqual(future_column_text);
    }

    if (move_direction == -1) {
      // Нумерация в массивах начинается с 0, поэтому дополнительно вычитаем 1
      var next_future_column_text2 = all_columns.get(future_column_number).element(by.css(column_text_css)).getText();
      expect(next_future_column_text2).toEqual(future_column_text);
    }

    // Проверяем, что для рядомстоящего элемента перемещение было произведено верно
    expect(future_column.element(by.css(column_text_css)).getText()).toEqual(current_column_text);

  });

});