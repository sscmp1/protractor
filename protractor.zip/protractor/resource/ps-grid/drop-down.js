/**
 * @file       drop-down.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При нажатии правой кнопки мыши выпадающий список появляется
 *
 * @created    [03.08.2015] Lilia Sapurina.
 */

describe('После клика правой кнопкой мыши', function() {

  var config = browser.params;
  var url = config.psGridUrl,
      grid,
      column,
      drop;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.xpath(psGridXpath));
    grid.waitReady();

    column = grid.getColumnHead(2);
    // Кликнем правой кнопкой мыши
    column.rightClick();

    drop = psDrop(by.xpath(psGridDropXpath));
    drop.waitReady();
  });

  it('появляется список', function() {
    // Проверим, что элемент отображается
    if (drop.isPresent()) {
      since('Список не отображается').
        expect(drop.isDisplayed()).toBe(true);
    }
  });

});