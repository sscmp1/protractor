/**
 * @file       ps-grid_no_arrow.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Если изначально стрелки нет, то кликнем на неё, получим стрелку вверх => сортировка по возрастанию
 *
 * @created    [03.08.2015] Lilia Sapurina.
 */

describe('ps-grid_no_arrow', function () {

  var config = browser.params;

  // Глобальные переменные
  var columns_xpath = config.columns_xpath;
  var column_number = config.column_number;
  var column_body_xpath = config.column_body_xpath_grid;

  // Поиск по локатору
  var all_columns = element.all(by.xpath(columns_xpath));
  var current_column_body = element.all(by.xpath(column_body_xpath));

  var current_column = all_columns.get(column_number - 1);

  beforeEach(function(){
    browser.get('sbms/shell.html?shell_login=CMS_HAS&shell_password=qwerty&shell_modus=t&shell_modus=c');
    browser.executeScript("icms.go('WEB_INQ_PROC', 'InquiryList', null, 0)");
  });

  it('стрелки нет: после клика колонка отсортирована по возрастанию', function () {

    // Стрелки не было, значит на неё нужно кликнуть, стрелка долждна быть направлена вверх
    current_column.click();
    // Стрелка вверх, значит нужно проверить, что список отсортирован по возрастанию
    current_column_body.map(function (elm) {
      return elm.getText();
    }).then(function (values) {
      var sortedvalues = values.slice();
      sortedvalues = sortedvalues.sort(function (a, b) {
        if (a > b) {
          return 1;
        }
      });
      expect(values).toEqual(sortedvalues);
    });

  });

});