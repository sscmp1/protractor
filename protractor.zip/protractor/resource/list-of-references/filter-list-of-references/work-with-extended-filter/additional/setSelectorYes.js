/**
 * Created by Evgeniia.Bessarab on 19.10.2015.
 */

describe('Установка переключателя: "Да"', function () {

  var lib = require("../common.js"),
      config = browser.params,
      url = config.listOfReferencesUrl,
      toolbar,
      tabs,
      additionalTabName="Дополнительно",
      repeatInqRadioGroup,
      repeatPeriod;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");
    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css("ps-toolbar[class='n-panel no-select']"));
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();
    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath("//ul[@class='n-tabs']"));
    // Кликнем на вкладку "Дополнительно"
    tabs.getTabByName(additionalTabName).click();
  });


   it('Внешний вид. Заголовок.', function () {
     var captionText= 'Выводить только повторные обращения',
         repeatInqCaption = element(by.xpath("//label[@class='n-label'][contains(text(),'"+captionText+"')]"));
     since('Неправильно название заголовка. Не #{expected},а: #{actual}').
         expect(repeatInqCaption.getText()).toEqual(captionText);
   });

  it('Внешний вид. Название RadioButton\'ов.', function () {
    repeatInqRadioGroup=psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    since('Неправильное название RadioButton. Не #{expected},а: #{actual}').
        expect(repeatInqRadioGroup.getCaption(1).getText()).toEqual('Да');
    since('Неправильное название RadioButton. Не #{expected},а: #{actual}').
        expect(repeatInqRadioGroup.getCaption(2).getText()).toEqual('Нет');
  });

  it('Внешний вид. Период повторения.', function () {
    var captionText= 'Период повторения',
        repeatInqCaption = element(by.xpath("//label[@class='n-label'][contains(text(),'"+captionText+"')]"));
    since('Неправильное название заголовка. Не #{expected},а: #{actual}').
        expect(repeatInqCaption.getText()).toEqual(captionText);
  });

  it('Внешний вид. Значение radio button по умолчанию.', function () {
    repeatInqRadioGroup=psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    since('Неправильное значение radio button по-умолчанию. Не #{expected},а: #{actual}').
        expect(repeatInqRadioGroup.getRadioButtonWithGreenBall().getText()).toEqual('Нет');
    since('Неправильное состояние у поля "Период повторения". Не #{expected},а: #{actual}').
        expect(repeatPeriod.getState()).toEqual('disable');
  });

  it('Внешний вид. Доступность поля "Период повторения".', function () {
    repeatPeriod=psDuration(by.xpath("//div[contains(@class,'ps-duration')]"));
    since('Неправильное состояние у поля "Период повторения". Не #{expected},а: #{actual}').
        expect(repeatPeriod.getState()).toEqual('disable');
  });

  it('После нажатия кнопки очистить.', function () {
    lib.getClearButton().click();
    repeatPeriod=psDuration(by.xpath("//div[contains(@class,'ps-duration')]"));
    repeatInqRadioGroup=psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    since('Неправильное значение radio button по-умолчанию. Не #{expected},а: #{actual}').
        expect(repeatInqRadioGroup.getRadioButtonWithGreenBall().getText()).toEqual('Нет');
    since('Неправильное значение маски ввода. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getTextValue()).toEqual('00 сут. 00:01');
    since('Неправильное состояние у поля "Период повторения". Не #{expected},а: #{actual}').
        expect(repeatPeriod.getState()).toEqual('disable');
  });

  it('Установить переключатель "Да"', function () {
    repeatPeriod=psDuration(by.xpath("//div[contains(@class,'ps-duration')]"));
    repeatInqRadioGroup=psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    repeatInqRadioGroup.clickOnCaption("Да");
    since('Неправильно выбран radio button. Не #{expected},а: #{actual}').
        expect(repeatInqRadioGroup.getRadioButtonWithGreenBall().getText()).toEqual('Да');
    since('Неправильное значение маски ввода. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getTextValue()).toEqual('00 сут. 00:01');
    since('Неправильное состояние у поля "Период повторения". Не #{expected},а: #{actual}').
        expect(repeatPeriod.getState()).toEqual('enable');
  });

  it('Нажать "Применить"', function () {
    lib.getApplyButton().click();
    // Проверяем,что перешли на список обращений
    var result = element(by.xpath("//div[@load-form='inquiryListFilter'][contains(@class,'ng-hide')]")) &&
                 element(by.xpath("//ps-splitter[@ng-hide='formData.state.showFilter'][not(contains(@class,'ng-hide'))]")) ? true : false;
    since('Мы не перешли на список обращений. Не #{expected},а: #{actual}').
        expect(result).toEqual(true);
  });

  it('Снова открыть форму фильтра, закладку "Дополнительно"', function () {
    toolbar = psToolbar(by.css("ps-toolbar[class='n-panel no-select']"));
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();
    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath("//ul[@class='n-tabs']"));
    // Кликнем на вкладку "Дополнительно"
    tabs.getTabByName(additionalTabName).click();

    repeatPeriod=psDuration(by.xpath("//div[contains(@class,'ps-duration')]"));
    repeatInqRadioGroup=psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    since('Неправильно выбран radio button. Не #{expected},а: #{actual}').
        expect(repeatInqRadioGroup.getRadioButtonWithGreenBall().getText()).toEqual('Да');
    since('Неправильное состояние у поля "Период повторения". Не #{expected},а: #{actual}').
        expect(repeatPeriod.getState()).toEqual('enable');
    since('Неправильное значение маски ввода. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getTextValue()).toEqual('00 сут. 00:01');
  });


});

