/**
 * Created by Evgeniia.Bessarab on 19.10.2015.
 */

describe('Смена периода повторения', function () {

  var lib = require("../common.js"),
      config = browser.params,
      url = config.listOfReferencesUrl,
      toolbar,
      tabs,
      additionalTabName="Дополнительно",
      repeatInqRadioGroup,
      repeatPeriod,
      firstEnter= {
        startTime: "",
        stateFieldTime:"",
        radioButtonNameWithBall: ""
      };

  beforeAll(function () {
    var request = require('request');

    var options = {
      method: 'POST',
      url: 'http://myurl.com/endpoint/test/',
      headers: {'id': 'AQ8WHWC',
        'sessionid': 'XnINW5KDQg=',
        'Accept': 'application/json',
        'Accept-Language': 'en-us',
        'random': 'BS3P5Q'
      },
      body: '{ "pay_load": [] }'
    };

    function callback(error, response, body) {
      if (!error && response.statusCode == 200) {
        var info = JSON.parse(body);
        console.log(response);
        console.log(info);
      }
    }
    request(options, callback);

    // Загружаем страницу списка обращений
    load(url, "list-of-references");
    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css("ps-toolbar[class='n-panel no-select']"));
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();
    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath("//ul[@class='n-tabs']"));
    // Кликнем на вкладку "Дополнительно"
    tabs.getTabByName(additionalTabName).click();
    repeatPeriod=psDuration(by.xpath("//div[contains(@class,'ps-duration')]"));
    repeatInqRadioGroup=psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
  });

  it('Нажать "Очистить"', function () {
    lib.getClearButton().click();
    // Проверяем,что перешли на список обращений
    repeatInqRadioGroup.clickOnCaption("Да");
    since('Неправильное состояние у поля "Период повторения" после клика Да. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getState()).toEqual('enable');
  });

  it('Ввести в поле "Период повторения" любое валидное значение', function () {
    repeatPeriod.sendKeys('22 сут. 22:22');
    since('Неправильно введено значение 22 сут. 22:22. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getTextValue()).toEqual('22 сут. 22:22');
  });

  it('Установить переключатель в значение "Нет"', function () {
    repeatInqRadioGroup.clickOnCaption("Нет");
    firstEnter.stateFieldTime=repeatPeriod.getTextValue();
    since('Неправильное состояние у поля "Период повторения" после клика Нет. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getState()).toEqual('disable');
  });

  it('Снова установить переключатель в значение "Да"', function () {
    repeatInqRadioGroup.clickOnCaption("Да");
    since('Неправильное состояние у поля "Период повторения" после клика Да. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getState()).toEqual('enable');
    since('Значение времени периода повторения не соответствует состоянию на момент начала выполнения теста. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getTextValue()).toEqual(firstEnter.stateFieldTime);
  });

});

