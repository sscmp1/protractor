/**
 * @file       clear.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что после нажатия кнопки очистки в поле устанавливается значение по умолчанию
 *
 * @created    [18.09.2015] Lilia Sapurina.
 */

describe('После нажатия на кнопку "Очистить"', function () {

  var config = browser.params;
  var lib = require("../common.js"),
      url = config.listOfReferencesUrl,
          toolbar,
          tabs,
          client,
          list,
          radioGroup;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();

    lib.getClearButton().click();
  });

  it('выбранный элемент: "Все клиенты"', function () {
    since('Выбранный элемент не "Все клиенты", а "#{actual}"').
            expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
  });

  it('дополнительные параметры фильтрации не отображаются', function () {
    since('Отображается "#{actual}" дополнительных параметров фильтрации').
            expect(list.getTableLabeles().count()).toEqual(1);
  });

});
