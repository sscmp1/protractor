/**
 * @file       client-parameters.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при выборе мышью пункта "Параметры клиента" отображаются все нужные поля
 *
 * @created    [23.09.2015] Lilia Sapurina.
 */

describe('После выбора пункта "Параметры клиента" мышью и клика не него', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      toolbar,
      tabs,
      client,
      list,
      radioGroup;

  // Порядковые номера фильтрующих полей
  var clientNameNum = clientParameters.clientName,
          categoryNum = clientParameters.category,
          featureNum = clientParameters.feature,
          classNum = clientParameters.class,
          statusNum = clientParameters.status,
          filialNum = clientParameters.filial,
          unionNum = clientParameters.union,
          planNum = clientParameters.plan,
          balanceNum = clientParameters.balance;

  // Фильтрующие поля
  var clientName,
          category,
          feature,
          classF,
          status,
          filial,
          union,
          plan,
          balance;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();

    radioGroup.clickOnCaption("Параметры клиента");

    clientName = list.getTableLabeles().get(clientNameNum);
    category = list.getTableLabeles().get(categoryNum);
    feature = list.getTableLabeles().get(featureNum);
    classF = list.getTableLabeles().get(classNum);
    status = list.getTableLabeles().get(statusNum);
    filial = list.getTableLabeles().get(filialNum);
    union = list.getTableLabeles().get(unionNum);
    plan = list.getTableLabeles().get(planNum);
    balance = list.getTableLabeles().get(balanceNum);

  });

  it('выбранный элемент: "Параметры клиента"', function () {
    since('Выбранный элемент не "Параметры клиента", а "#{actual}"').
            expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
  });

  it('отображается параметр фильтрации "Наименование клиента"', function () {
    since('Отображается параметр фильтрации не "Наименование клиента", а "#{actual}"').
            expect(clientName.getText()).toEqual("Наименование клиента");
  });

  it('отображается параметр фильтрации "Категория"', function () {
    since('Отображается параметр фильтрации не "Категория", а "#{actual}"').
            expect(category.getText()).toEqual("Категория");
  });

  it('отображается параметр фильтрации "Признак"', function () {
    since('Отображается параметр фильтрации не "Признак", а "#{actual}"').
            expect(feature.getText()).toEqual("Признак");
  });

  it('отображается параметр фильтрации "Класс"', function () {
    since('Отображается параметр фильтрации не "Класс", а "#{actual}"').
            expect(classF.getText()).toEqual("Класс");
  });

  it('отображается параметр фильтрации "Статус"', function () {
    since('Отображается параметр фильтрации не "Статус", а "#{actual}"').
            expect(status.getText()).toEqual("Статус");
  });

  it('отображается параметр фильтрации "Филиал"', function () {
    since('Отображается параметр фильтрации не "Филиал", а "#{actual}"').
            expect(filial.getText()).toEqual("Филиал");
  });

  it('отображается параметр фильтрации "Объединение"', function () {
    since('Отображается параметр фильтрации не "Объединение", а "#{actual}"').
            expect(union.getText()).toEqual("Объединение");
  });

  it('отображается параметр фильтрации "Тарифный план"', function () {
    since('Отображается параметр фильтрации не "Тарифный план", а "#{actual}"').
            expect(plan.getText()).toEqual("Тарифный план");
  });

  it('отображается параметр фильтрации "Баланс"', function () {
    since('Отображается параметр фильтрации не "Баланс", а "#{actual}"').
            expect(balance.getText()).toEqual("Баланс");
  });

});

