/**
 * @file       apply.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что после нажатия кнопки "Применить" форма закрыта
 *
 * @created    [18.09.2015] Lilia Sapurina.
 */

describe('После нажатия на кнопку "Применить"', function () {

  var config = browser.params;
  var lib = require("../common.js"),
      url = config.listOfReferencesUrl,
          toolbar,
          tabs,
          client,
          list;
  var baseUrl = browser.baseUrl;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    // Ищем компонент ps-List на странице
    list = psList(by.xpath(psListClientId));
    list.waitReady();

    // Ищем кнопку "Применить"
    lib.getApplyButton().click();
  });

  it('открыт список обращений', function () {
    since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
            expect(browser.getCurrentUrl()).toBe(baseUrl + url);
  });

});

