/**
 * @file       refresh-not-exist.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при вводе несуществующего значения в поле номера и обновлении страницы, отфильтрованная колонка становится пустой
 *
 * @created    [25.08.2015] Lilia Sapurina.
 */

describe('После ввода несуществующего номера обращения и обновления', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      grid,
      toolbar,
      numberField;

  beforeAll(function() {
    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Внутри компонента ps-Grid ищем быстрый фильтр поля "Номер" (1-я колонка)
    numberField = grid.getQuickFilter(gridFilter.number);

    // Кликнем на поле "Номер" и введём несуществующее значение
    numberField.click().sendKeys("666");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления и кликаем её
    toolbar.getRefreshButton().click();
  });

  it('в поле "Номер" сохранилось введённое значение', function () {
    // В поле номер должно сохраниться введённое несуществующее значение
    since('В отфильтрованном списке запись не равна #{expected}, а равна: #{actual}').
            expect(numberField.getInputText()).toEqual("666");
  });

  it('список пуст', function () {
    // Внутри компонента ps-Grid ищем содержимое колонки "Номер" после ввода номера в фильтр (1-я колонка)
    var column = grid.getColumn(gridFilter.number);
    since('Список не пуст').
            expect(column.count()).toEqual(0);
  });

});