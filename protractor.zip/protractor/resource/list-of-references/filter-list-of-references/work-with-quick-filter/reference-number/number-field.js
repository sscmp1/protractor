/**
 * @file       number-field.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что в поле быстрого фильтра номера нельзя вводить ничего кроме цифр
 *
 * @created    [24.08.2015] Lilia Sapurina.
 */

describe('После ввода символов в поле "Номер" списка обращений', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      grid,
      numberField;

  beforeAll(function() {
    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Внутри компонента ps-Grid ищем быстрый фильтр поля "Номер" (1-я колонка)
    numberField = grid.getQuickFilter(gridFilter.number);
    // Кликаем в поле быстрого фильтра и вводим символьное сообщение
    numberField.click().sendKeys("Hello!");
  });

  it('поле пустое', function () {
    since('Поле "Номер" при вводе символов не становится пустым, а равен: #{actual}').
            expect(numberField.getInputText()).toEqual("");
  });

});