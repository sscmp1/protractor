/**
 * @file       clear-and-refresh.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при нажатии кнопки очистить и обновить, фильтр номера очищается, а в списке отфильтрованных значений хранятся обращения зарегистрированные за текущий день
 *
 * @created    [25.08.2015] Lilia Sapurina.
 */

describe('После нажатия кнопки очистки и обновления', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      grid,
      toolbar,
      numberField,
      column;

  beforeAll(function() {
    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку очистки
    toolbar.getClearButton().click();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getRefreshButton().click();

    // Внутри компонента ps-Grid ищем быстрый фильтр поля "Номер" (1-я колонка)
    numberField = grid.getQuickFilter(gridFilter.number);
  });

  it('поле "Номер" пусто', function () {
    since('Поле "Номер" при вводе символов не становится пустым, а равен: #{actual}').
            expect(numberField.getInputText()).toEqual("");
  });

  it('в списке отображаются обращения за текущий день', function () {
    // Внутри компонента ps-Grid ищем содержимое колонки "Дата" (5-я колонка)
    column = grid.getColumn(gridFilter.registrationDate);

    column.each(function (element) {
      since('В отфильтрованном списке не текущая дата,a: #{actual}').
              expect(element.getText('class')).toContain(today_only_date());
    });
  });
});