/**
 * @file       add-several-second-references.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview После добавления через запятую номера второго обращения несколько раз список фильтруется верно
 *
 * @created    [26.08.2015] Lilia Sapurina.
 */

describe('После установления существующего значения в поле "Номер" и любых значений в остальные поля быстрого фильтра и добавления к нему несколько раз через запятую номера второго обращения', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      grid,
      toolbar,
      existValue1,
      existValue2,
      column;

  beforeAll(function() {
    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Внутри компонента ps-Grid ищем содержимое колонки "Номер" (1-я колонка)
    column = grid.getColumn(gridFilter.number);

    // Заполним поля быстрых фильтров "Номер" и "Дата"
    existValue1 = column.get(0).getText().then(function(value){
      grid.getQuickFilter(gridFilter.number).click().sendKeys(value);
      return value;
    });
    grid.getColumn(gridFilter.registrationDate).get(0).getText().then(function(value){
      grid.getQuickFilter(gridFilter.registrationDate).click().sendKeys(value);
      return value;
    });

    // Внутри компонента ps-Grid ищем содержимое колонки "Номер" (1-я колонка) и выбираем содержимое 2-го обращения
    existValue2 = grid.getColumn(gridFilter.number).get(1).getText().then(function(text) {
      // Добавляем в поле номера номер второго обращения через точку с запятой
      grid.getQuickFilter(gridFilter.number).click().sendKeys(',' + text + ',' + text + ',' + text);
      return text;
    });

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getRefreshButton().click();
  });

  it('в списке два обращения', function () {
    since('В отфильтрованном списке записей не #{expected},их: #{actual}').
            expect(column.count()).toEqual(2);
  });

  it('первое обращение соответствует фильтрации', function () {
    since('В отфильтрованном номер записи не #{expected},a: #{actual}').
            expect(column.get(0).getText()).toEqual(existValue1);
  });

  it('второе обращение соответствует фильтрации', function () {
      since('В отфильтрованном номер записи не #{expected},a: #{actual}').
              expect(column.get(1).getText()).toEqual(existValue2);
  });

});

