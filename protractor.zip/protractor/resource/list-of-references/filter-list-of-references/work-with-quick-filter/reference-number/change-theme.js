/**
 * @file       change-theme.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при вводе существующего номера, статуса и даты, при изменении темы на любую, список сохраняет фильтрацию
 *
 * @created    [24.08.2015] Lilia Sapurina.
 */

describe('После установления значений в полях быстрого фильтра, соответсвующих зарегистрированному обращению и любой темы', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      grid,
      toolbar,
      existValue,
      column;

  beforeAll(function() {
    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Внутри компонента ps-Grid ищем содержимое колонки "Номер" (1-я колонка)
    column = grid.getColumn(gridFilter.number);

    // Заполним поля быстрых фильтров "Номер","Тема","Статус" и "Дата"
    existValue = column.get(0).getText().then(function(value){
      grid.getQuickFilter(gridFilter.number).click().sendKeys(value);
      return value;
    });

    grid.getColumn(gridFilter.registrationDate).get(0).getText().then(function(value){
      grid.getQuickFilter(gridFilter.registrationDate).click().sendKeys(value);
    });

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getRefreshButton().click();
  });

  it('в списке одно обращение', function () {
    since('В отфильтрованном списке запись не #{expected},их: #{actual}').
            expect(column.count()).toEqual(1);
  });

  it('поле "Номер" верно отфильтровано', function () {
    since('В отфильтрованном номер записи не #{expected},a: #{actual}').
            expect(column.get(0).getText()).toEqual(existValue);
  });

});