/**
 * @file       ps-grid-column-filter-range_filter_interval.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Ввод существующего диапазона (например, [первое значение в списке] - [оно же, округленное до ближайшего большего числа]): корректная фильтрация
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_filter_interval', function () {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var column_body_xpath = config.column_body_xpath;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));
  var column_body = element.all(by.xpath(column_body_xpath));

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });


  it('корректная фильтрация по интервалу', function () {
    filter_field.click();

    // Возьмём первый элемент списка (если он существует) и его округлённое сверху значение
    if (column_body.get(0).isPresent()) {
      var exist_value1 = column_body.get(0).getText().then(function (value) {
        var floatValue = parseFloat(value);
        return (floatValue);
      });
      var exist_value2 = column_body.get(0).getText().then(function (value) {
        var floatValue = parseFloat(value);
        return Math.round(floatValue) + 1;
      });
      filter_field.sendKeys(exist_value1);
      filter_field.sendKeys('-');
      filter_field.sendKeys(exist_value2);
      var filtered_values = element.all(by.xpath(column_body_xpath));

      // Проверим, что отфильтрованный список содержит верные значения
      filtered_values.each(function (element) {
        var current_value = element.getText().then(function (value) {
          var floatValue = parseFloat(value);
          return (floatValue);
        });
        expect((exist_value1 <= current_value) || (exist_value2 >= current_value)).toBeTruthy();
      });
    }
    else {
      expect(true).toBe(false);
    }

  });

});
