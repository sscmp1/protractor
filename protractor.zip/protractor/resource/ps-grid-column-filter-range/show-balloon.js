/**
 * @file       ps-grid-column-filter-range_show_balloon.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При клике в пустое поле отображается balloon
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_show_balloon', function () {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var balloon_info_css = config.balloon_info_css;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));
  var balloon_info = $(balloon_info_css);

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('балун демонстрируется', function () {
    filter_field.click();
    browser.actions().click(filter_field).perform();

    browser.wait(function () {
      return balloon_info.isPresent();
    },5000).then(function () {
      expect(balloon_info.isDisplayed()).toBe(true);
    }
    ,function () {
      expect(false).toBe(true);
    });

  });

});
