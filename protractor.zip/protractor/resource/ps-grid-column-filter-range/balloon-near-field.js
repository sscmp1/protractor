/**
 * @file       ps-grid-column-filter-range_balloon_near_field.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview balloon отображается рядом с полем
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_balloon_near_field', function () {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var balloon_info_css = config.balloon_info_css;
  var x_distance = config.x_distance;
  var y_distance = config.y_distance;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));
  var balloon_info = $(balloon_info_css);

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('балун демонстрируется рядом с полем', function () {
    filter_field.click();
    browser.actions().click(filter_field).perform();

    // Проверку делаем только в том случае, если балун появился
    browser.wait(function () {
      return balloon_info.isPresent();
    }, 3000).then(function () {
      var filter_field_x = 0;
      var filter_field_y = 0;

      filter_field.getLocation().then(function (navDivLocation) {
        filter_field_x = navDivLocation.x;
        filter_field_y = navDivLocation.y;

        balloon_info.getLocation().then(function (navDivLocation2) {
          var balloon_x = navDivLocation2.x;
          var balloon_y = navDivLocation2.y;

          // Должны располагаться друг от друга не более, чем на 10 по х, не более, чем на 40 по у
          expect(balloon_x - filter_field_x).toBeLessThan(x_distance) && (balloon_y
                  - filter_field_y).toBeLessThan(y_distance);
        });
      });
    }).thenCatch(function () {
      expect(true).toBe(false);
    });

  });

});
