/**
 * @file       ps-grid-column-filter-range_unknown_value.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Если значение отсутствует в списке, отображается сообщение "Нет данных"
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_unknown_value', function() {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var no_data_field_xpath = config.no_data_field_xpath;
  var value_not_from_list = config.value_not_from_list;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));
  var no_data_field = element(by.xpath(no_data_field_xpath));

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('при значении не из списка демонстрируется сообщение nodata',function(){

     filter_field.click();
     filter_field.sendKeys(value_not_from_list);

    browser.wait(function () {
      return no_data_field.isPresent();
    }).then(function () {
              expect(no_data_field.getText()).toEqual('Нет данных');
    }
    ,function () {
              expect(false).toBe(true);
    });

  });

});
