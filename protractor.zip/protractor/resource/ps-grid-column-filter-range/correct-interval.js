/**
 * @file       ps-grid-column-filter-range_correct_interval.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При вводе невалидного диапазона (например, 2 - 1) выполняется попытка заменить его на валидный (2 - 10)
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_correct_interval', function() {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('некорректные интервалы должны корректироваться',function(){
     filter_field.click();
     // Введём неверный интервал
     filter_field.sendKeys('2-1');
     filter_field.click();
     // Значение в поле должно быть скорректированно
     expect(filter_field.getAttribute("value")).toEqual('2 – 10');

  });

});