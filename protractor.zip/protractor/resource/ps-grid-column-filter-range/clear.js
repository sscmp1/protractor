/**
 * @file       ps-grid-column-filter-range_clear.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Очистка поля
 *
 * @created    [28.07.2015] Lilia.Sapurina.
*/

describe('ps-grid-column-filter-range_clear', function() {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var correct_value = config.correct_value;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('поле должно корректно очищаться',function(){
     filter_field.click();
     filter_field.sendKeys(correct_value);
     // Очистим поле
     filter_field.clear();
     // Проверим, что поле очистилось
     expect(filter_field.getAttribute("value")).toEqual('');

  });

});
