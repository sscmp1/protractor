/**
 * @file       click-cross.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При нажатии на крестик календарь закрывается
 *
 * @created    [31.07.2015] Lilia.Sapurina.
 */

describe('При нажатии на крестик', function () {

  var config = browser.params,
          url = config.psDateTimePickerUrl,
          datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();
    datePicker.getCalendarButton().click();
    datePicker.getCross().click();
  });

  it('календарь закрывается', function () {
    since('Календарь открыт').
      expect(datePicker.getCalendar().isDisplayed()).toBe(false);
  });
});