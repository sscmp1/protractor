/**
 * @file      date-to-field.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При вводе даты в поле и нажатии на кнопку календаря появляется лист с соответствующим месяцем и годом
 *
 * @created    [07.08.2015] Lilia Sapurina.
 */

describe('При вводе даты в поле и нажатии на кнопку календаря', function () {

  var config = browser.params;
  var inputDate = datePickerValue.inputDate,
      url = config.psDateTimePickerUrl,
      datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();

    datePicker.getField().clear().sendKeys(inputDate);
    datePicker.getCalendarButton().click();
  });

  it('появляется лист с соответствующим месяцем и годом', function () {

    datePicker.getField().getInputText().then(function (value) {

      // Парсим поле календаря
      var parseCalendarField = value.split('.');

      datePicker.getMonthYear().getText().then(function (m_y) {

        // Парсим поле с месяцем и годом
        var parseMonthYear = m_y.split(' ');
        var yyyy = parseMonthYear[1];
        // Переведём название месяца в его номер (нумерация с нуля)
        var month = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь',
          'Ноябрь', 'Декабрь'];
        var mm = month.indexOf(parseMonthYear[0]) + 1;

        if (mm < 10) {
          mm = '0' + mm;
        }

        since('Значение месяца в календаре не #{expected},а: #{actual}').
           expect(mm).toEqual(parseCalendarField[1]);

        // Ещё раз парсим, т.к. там ещё и время
        since('Значение года в календаре не #{expected},а: #{actual}').
           expect(yyyy).toEqual(parseCalendarField[2].split(' ')[0]);
      });
    });

  });
});