/**
 * @file       double-click.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При двойном клике календарь закрывается
 *
 * @created    [31.07.2015] Lilia.Sapurina.
 */

describe('При двойном клике', function () {

  var config = browser.params,
          url = config.psDateTimePickerUrl,
          datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();
    datePicker.getCalendarButton().doubleClick();
  });

  it('календарь закрывается', function () {
    expect(datePicker.getCalendar().isDisplayed()).toBe(true);
  });

});