/**
 * @file       current-time.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка всех полей из выпадающего списка: "Текущее время"
 *
 * @created    [07.08.2015] Lilia Sapurina.
 */

describe('При выборе поля из выпадающего списка "текущее время"', function () {

  var config = browser.params,
          url = config.psDateTimePickerUrl,
          datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();

    datePicker.getField().clear();
    datePicker.getField().sendKeys('Текущее время');
    datePicker.getCalendarButton().click();

    datePicker.getSelectedValue().click();
  });

  it('в календаре устанавливается текущее время', function () {
    since('Значение календаря не #{expected},а: #{actual}').
      expect(datePicker.getField().getAttribute("value")).toEqual(today());
  });
});