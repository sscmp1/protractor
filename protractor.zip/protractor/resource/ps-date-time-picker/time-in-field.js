/**
 * @file       time-in-field.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При движении скроллера время, указываемое снизу, равно устанавливаемому в поле времени
 *
 * @created    [04.08.2015] Lilia Sapurina.
 */

describe('При движении скроллера время, указываемое снизу', function () {

  var config = browser.params,
          moveDirection = datePickerValue.moveDirection,
          moveSize = datePickerValue.moveSize,
          deferred = protractor.promise.defer(),
          url = config.psDateTimePickerUrl,
          datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();

    datePicker.getCalendarButton().click();
  });

  it('равно устанавливаемому в поле времени', function () {

    // Перемещаем scroller в зависимости от параметра move_direction вправо или влево
    if (datePicker.getScroller().isPresent()) {
      datePicker.getScroller().dragAndDrop(moveSize * moveDirection, 0);

      // Проверим, что указываемое под скроллером время в данный момент указано и в поле календаря
      since('Время не верное: не #{expected},а: #{actual}').
          expect(datePicker.getField().getInputText()).toContain(datePicker.getTimeUnderScroll().getText());
    }
    else {
      deferred.reject('scroller не представлен');
    }

  });
});