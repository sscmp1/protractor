/**
 * @file       select-text-with-shift.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview После выделения текста при помощи комбинации клавиш shift + стрелка текст выделяется верно
 *
 * @created    [10.09.2015] Lilia Sapurina.
 */

describe('После выделения текста при помощи shift + стрелка', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field,
          highligtedText;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
    field.clear().click().sendKeys('Hello');

    browser.actions()
            .keyDown(protractor.Key.SHIFT)
            .sendKeys(protractor.Key.ARROW_LEFT)
            .sendKeys(protractor.Key.ARROW_LEFT)
            .sendKeys(protractor.Key.ARROW_LEFT)
            .sendKeys(protractor.Key.ARROW_LEFT)
            .sendKeys(protractor.Key.ARROW_LEFT)
            .keyUp(protractor.Key.SHIFT)
            .perform();

    highligtedText = field.getHighlightedText();
  });

  it('текст выделяется верно', function () {
    since('Выделенное значение не #{expected},а: #{actual}').
            expect(highligtedText).toEqual('Hello');
  });

});



