/**
 * @file       select-text-double-click.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что текст верно выделяется при двойном клике
 *
 * @created    [10.09.2015] Lilia Sapurina.
 */

describe('После выделения текста двойным щелчком:', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field,
          highligtedText;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
    field.clear().click().sendKeys('Hello');
    field.doubleClick();

    highligtedText = field.getHighlightedText();
  });

  it('текст выделяется верно', function () {
    since('Выделенное значение не #{expected},а: #{actual}').
            expect(highligtedText).toEqual('Hello');
  });

});

