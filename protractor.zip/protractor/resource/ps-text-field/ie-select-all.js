/**
 * @file       ie-select-all.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что использование контекстного меню IE работает: пункт "Выделить всё"
 *
 * @created    [10.09.2015] Lilia Sapurina.
 */

describe('После нажатия пункта "Выделить всё" в контекстном меню IE', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field,
          highligtedText;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
    field.clear().sendKeys("Hello");
    field.rightClick();

    browser.sleep(2000);

    browser.actions().sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN)
            .sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.ENTER).perform();

    highligtedText = field.getHighlightedText();
  });

  it('текст выделяется верно', function () {
    since('Выделенное значение не #{expected},а: #{actual}').
            expect(highligtedText).toEqual('Hello');
  });

});
