/**
 * @file       edit-value-ctrlz.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при нажатии комбинации клавиш CTRL + Z введённые изменения отменяются
 *
 * @created    [04.09.2015] Lilia Sapurina.
 */

describe('После нажатия комбинации клавиш CTRL + Z', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Вводим произвольное сообщение и удаляем последний символ
    field = textField.getTextField(1);
    field.clear();
    field.click().sendKeys("Hello!");
    field.pushKeyCombo("CTRL","Z");
  });

  it('введённое в поле значение отменяется', function () {
    since('Значение осталось прежним').
            expect(field.getInputText()).toEqual("");
  });

});

