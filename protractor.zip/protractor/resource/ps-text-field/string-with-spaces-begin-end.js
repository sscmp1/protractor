/**
 * @file       string-with-spaces-begin-end.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка возможности ввода строки с пробелами в начале и конце
 *
 * @created    [05.09.2015] Lilia Sapurina.
 */

describe('После ввода строки с пробелами в начале и конце', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
    field.clear().click().sendKeys(' Hello! ');
  });

  it('строка отображается корректно', function () {
    since('Обновлённое значение не #{expected},а: #{actual}').
            expect(field.getInputText()).toEqual(' Hello! ');
  });

});

