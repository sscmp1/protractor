/**
 * @file       empty-default-value.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что значение по умолчанию пусто
 *
 * @created    [04.09.2015] Lilia Sapurina.
 */

describe('Значение по умолчанию в поле "Норма"', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();
  });

  it('пусто', function () {
    since('Значение по умолчанию не пусто,а равно: #{actual}').
            expect(textField.getDefaultField(1).getInputText()).toEqual("");
  });

});