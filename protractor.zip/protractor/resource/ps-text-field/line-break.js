/**
 * @file       line-break.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка возможности переноса строки в многострочном поле
 *
 * @created    [10.09.2015] Lilia Sapurina.
 */

describe('После нажатия ENTER в многострочном поле', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field,
          oldX,
          newX;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке (н.у.о. это первое многострочное поле)
    field = textField.getTextField(6);
    field.clear().click().sendKeys("Hello");
    // Извлекли положение курсора в строке
    oldX = field.getCaretPosition();
    browser.actions().sendKeys(protractor.Key.ENTER).perform();

    // Извлекли новое положение курсора - 10
    newX = field.getCaretPosition().then(function (value) {
      return value - 10;
    });
  });

  it('курсор перемещается на строку ниже', function () {
    since('Курсор не переместился: прежняя позиция курсора: #{expected} < новая позиция курсора: #{actual}').
            expect(oldX).toBeGreaterThan(newX);
  });

});

