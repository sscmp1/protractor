/**
 * @file       select-text-with-mouse.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview После выделения текста при помощи мыши текст выделяется верно
 *
 * @created    [10.09.2015] Lilia Sapurina.
 */

describe('После выделения текста при помощи мыши', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field,
          highligtedText;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
    field.clear().click().sendKeys('Hello');

    browser.actions()
            .dragAndDrop(field,{x:-50, y:0})
            .perform();

    highligtedText = field.getHighlightedText();
  });

  it('текст выделяется верно', function () {
    since('Выделенное значение не #{expected},а: #{actual}').
            expect(highligtedText).toEqual('Hello');
  });

});

