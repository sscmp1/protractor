/**
 * @file       chosen-client.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Последовательный сценарий на фильтр вкладки клиент списка обращений: "Выбранный клиент"
 *
 * @created    [30.09.2015] Lilia Sapurina.
 */

describe('1. После ввода значений в поля быстрого фильтра, открытия страницы с фильтром, нажатия кнопки "Очистить", перехода на кладку "Клиент" и установки значения фильтрации "Выбранный клиент"', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      grid,
      clientName,
      toolbar,
      list,
      tabs,
      client,
      clientField,
      abonentsField,
      radioGroup;

  // Порядковые номера фильтрующих полей
  var clientNameNum = gridFilter.clientName;

  // Порядковые номера фильтрующих полей
  var clientNum = clientParameters.client,
      abonentsNum = clientParameters.abonents - 1;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Внутри компонента ps-Grid ищем содержимое колонки "Имя клиента" (4-я колонка)
    grid.getColumn(gridFilter.clientName).get(0).toPsGrid().waitReady();
    clientName = grid.getQuickFilter(clientNameNum);
    clientName.click().sendKeys("Васильев Антон Георгиевич");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();

    // Внутри компонента ps-Toolbar ищем кнопку очистки
    toolbar.getClearButton().click();

    // Внутри компонента ps-Toolbar ищем кнопку с биноклем
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    // Ищем компонент ps-List на странице
    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();

    // Устанавливаем переключатель к состояние "Выбранный клиент"
    radioGroup.clickOnCaption("Выбранный клиент");

    clientField = list.getTableValues().get(clientNum).toPsList().getInput();
    abonentsField = list.getTableValues().get(abonentsNum).toPsList().getInput();
  });

  it('поле "Клиент" разрешено', function () {
    since('поле "Клиент" не разрешено').
            expect(clientField.isEnabled()).toBe(true);
  });

  it('поле "Абоненты" запрещено', function () {
    since('поле "Абоненты" разрешено').
            expect(abonentsField.getAttribute('readonly')).toBeTruthy();
  });

  describe('2. После попытки ввести символы с клавиатуры в поле "Клиент"', function () {

    beforeAll(function () {
      clientField.sendKeys("Hello!");
    });

    it('поле не меняется', function () {
      since('В поле символы "#{actual}"').
              expect(clientField.getInputText()).toEqual("");
    });

    // Далее действия зависят от компонента dictionary => пока не реализовываю

  });
});

