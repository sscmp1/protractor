/**
 * @file       chosen-abonents.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Последовательный сценарий на фильтер вкладки клиент списка обращений: "Выбранные абоненты"
 *
 * @created    [25.09.2015] Lilia Sapurina.
 */

describe('1. Выделим обращение. После перехода на вкладку "Клиент" и выбора параметра фильтрации "Выбранные абоненты"', function () {

  var lib = require("../common.js");
  // Пока нет графы с телефонами абонентов введём какие-нибудь различные номера
  var phone1 = '+79219599996', phone2 = '+79119451866';

  var config = browser.params;
  var url = config.listOfReferencesUrl,
          grid,
          toolbar,
          tabs,
          list,
          client,
          radioGroup;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на страницу
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Выделяем первое обращение
    grid.getColumn(gridFilter.number).get(0).toPsGrid().waitReady();
    grid.getColumn(gridFilter.number).get(0).click();

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();
    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();

    // Устанавливаем переключатель к состояние "Выбранные абоненты"
    radioGroup.clickOnCaption("Выбранные абоненты");
  });

  it('выбранный элемент: "Выбранные абоненты"', function () {
    since('Выбранный элемент не "Выбранные абоненты", а "#{actual}"').
            expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранные абоненты");
  });

  describe('2. После установки фокуса на поле "Номера абонентов"', function () {

    var abonentsNumbersNum = clientParameters.abonentsNumbers - 1,
        abonentsNumbers;

    beforeAll(function () {
      abonentsNumbers = list.getTableValues().get(abonentsNumbersNum).toPsList().getInput();
      abonentsNumbers.click();
    });

    it('в конце поля отображается пиктограмма для очистки', function () {
      // Заглушка, пока не реализовано в форме
      since('В конце поля не отображается пиктограмма для очистки "#{actual}" ').
              expect(true).toEqual(true);
    });

    describe('3. После ввода в поле цифр от 0 до 9', function () {

      beforeAll(function () {
        abonentsNumbers.sendKeys('0123456789');
      });

      it('они отображаются корректно', function () {
        since('В поле не "0123456789",а: #{actual}').
                expect(abonentsNumbers.getInputText()).toEqual('0123456789');
      });

      describe('4. После нажатия кнопки очистки', function () {

        beforeAll(function () {
          // Кнопки очистки нет, пока чистим методами protractor
          abonentsNumbers.clear();
        });

        it('поле пусто', function () {
          since('Поле не пусто,а: #{actual}').
                  expect(abonentsNumbers.getInputText()).toEqual('');
        });

        describe('5. После ввода в поле символов Ё,Й', function () {

          beforeAll(function () {
            abonentsNumbers.sendKeys('ЁЙ');
          });

          it('они отображаются корректно', function () {
            since('В поле не "ЁЙ",а: #{actual}').
                    expect(abonentsNumbers.getInputText()).toEqual('ЁЙ');
          });

          // Место для пункта 6 - проверка того, что кнопка очистки отсутствует

          describe('7. После выделения содержимого поля и нажатия клавиши Del', function () {

            beforeAll(function () {
              // Выделили текст
              abonentsNumbers.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "a"));
              browser.actions().sendKeys(protractor.Key.DELETE).perform();
            });

            it('поле пусто', function () {
              since('Поле не пусто,а: #{actual}').
                      expect(abonentsNumbers.getInputText()).toEqual('');
            });

            describe('8. После ввода в поле символов <\'&">', function () {

              beforeAll(function () {
                abonentsNumbers.sendKeys('<\'&">');
              });

              it('они отображаются корректно', function () {
                since('В поле не "<\'&">",а: #{actual}').
                        expect(abonentsNumbers.getInputText()).toEqual('<\'&">');
              });

              describe('9. После удаления символов при помощи Backspace', function () {

                beforeAll(function () {
                  browser.actions().sendKeys(protractor.Key.BACK_SPACE)
                          .sendKeys(protractor.Key.BACK_SPACE)
                          .sendKeys(protractor.Key.BACK_SPACE)
                          .sendKeys(protractor.Key.BACK_SPACE)
                          .sendKeys(protractor.Key.BACK_SPACE).perform();
                });

                it('поле пусто', function () {
                  since('Поле не пусто,а: #{actual}').
                          expect(abonentsNumbers.getInputText()).toEqual('');
                });

                describe('10. После ввода украинских символов їЇєЄіІ', function () {

                  beforeAll(function () {
                    abonentsNumbers.sendKeys('їЇєЄіІ');
                  });

                  it('они отображаются корректно', function () {
                    since('В поле не "їЇєЄіІ",а: #{actual}').
                            expect(abonentsNumbers.getInputText()).toEqual('їЇєЄіІ');
                  });

                  describe('11. После дополнения текущего значения символами ; и телефонными номерами через пробел', function () {

                    beforeAll(function () {
                      abonentsNumbers.sendKeys(';' + phone1 + ' ' + phone2);
                    });

                    it('пробел и точка с запятой преобразованы в запятую', function () {
                      since('Преобразование не произошло, в поле: #{actual}').
                              expect(abonentsNumbers.getInputText()).toContain(',' + phone1 + ',' + phone2);
                    });

                    describe('12. После нажатия кнопки "Применить"', function () {

                      var baseUrl = browser.baseUrl;

                      beforeAll(function () {
                        lib.getApplyButton().click();
                      });

                      it('форма списка закрыта', function () {
                        since('форма не закрыта').
                                expect(list.isPresent()).toBe(false);
                      });

                      it('открыт список обращений', function () {
                        since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                                expect(browser.getCurrentUrl()).toBe(baseUrl + url);
                      });

                      // Нет поля абонент => заглушка
                      it('в списке только обращения с введёнными номерами', function () {
                        since('Обращения в списке не отфильтрованы').
                                expect(true).toBe(true);
                      });

                      // Нет поля абонент => заглушка
                      it('в поле "Абонент" быстрого фильтра отображается "їЇєЄіІ,phone1,phone2"', function () {
                        since('В быстром фильтре отображается не #{expected},а: #{actual}').
                                expect(true).toBe(true);
                      });

                      describe('13. После перехода на закладку фильтра списка обращений "Клиент"', function () {

                        beforeAll(function () {
                          // Подождём загрузки формы с кнопками
                          toolbar.waitReady();

                          toolbar.getSearchButton().click();
                          client.click();
                        });

                        it('выбранный элемент: "Выбранные абоненты"', function () {
                          since('Выбранный элемент не "Выбранные абоненты", а "#{actual}"').
                                  expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранные абоненты");
                        });

                        it('В поле "Номера абонентов" установлено прежнее значение', function () {
                          since('В поле "Номера абонентов" установлено не #{expected},а: #{actual}').
                                  expect(abonentsNumbers.getInputText()).toEqual('їЇєЄіІ'+','+phone1+','+phone2);
                        });

                        describe('14. После установки значения "Выбранный клиент" в поле выбора фильтрации', function () {

                          beforeAll(function () {
                            // Устанавливаем переключатель к состояние "Выбранный клиент"
                            radioGroup.clickOnCaption("Выбранный клиент");
                          });

                          it('поле "Номера абонентов" не отображается', function () {
                            since('Отображается поле "Номера абонентов"').
                                    expect(abonentsNumbers.getText()).not.toEqual("Номера абонентов");
                          });

                          describe('15. После нажатия клавиши "Отменить"', function () {

                            beforeAll(function () {
                              lib.getCancelButton().click();
                            });

                            it('форма списка закрыта', function () {
                              since('форма не закрыта').
                                      expect(list.isPresent()).toBe(false);
                            });

                            it('открыт список обращений', function () {
                              since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                                      expect(browser.getCurrentUrl()).toBe(baseUrl + url);
                            });

                            // Нет поля абонент => заглушка
                            it('в списке только обращения с введёнными номерами', function () {
                              since('Обращения в списке не отфильтрованы').
                                      expect(true).toBe(true);
                            });

                            // Нет поля абонент => заглушка
                            it('в поле "Абонент" быстрого фильтра отображается "їЇєЄіІ,phone1,phone2"', function () {
                              since('В быстром фильтре отображается не #{expected},а: #{actual}').
                                      expect(true).toBe(true);
                            });

                            describe('16. После перехода на закладку фильтра списка обращений "Клиент"', function () {

                              beforeAll(function () {
                                // Подождём загрузки формы с кнопками
                                toolbar.waitReady();

                                toolbar.getSearchButton().click();
                                client.click();
                              });

                              it('выбранный элемент: "Выбранные абоненты"', function () {
                                since('Выбранный элемент не "Выбранные абоненты", а "#{actual}"').
                                        expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранные абоненты");
                              });

                              it('В поле "Номера абонентов" установлено прежнее значение', function () {
                                since('В поле "Номера абонентов" установлено не #{expected},а: #{actual}').
                                        expect(abonentsNumbers.getInputText()).toEqual('їЇєЄіІ'+','+phone1+','+phone2);
                              });

                              describe('17. После установки значения "Выбранный клиент" в поле выбора списка фильтрации', function () {

                                beforeAll(function () {
                                  // Устанавливаем переключатель к состояние "Выбранный клиент"
                                  radioGroup.clickOnCaption("Выбранный клиент");
                                });

                                it('поле "Номера абонентов" не отображается', function () {
                                  since('Отображается поле "Номера абонентов"').
                                          expect(abonentsNumbers.getText()).not.toEqual("Номера абонентов");
                                });

                                describe('18. После установки значения "Выбранные абоненты" в поле выбора списка фильтрации', function () {

                                  beforeAll(function () {
                                    // Устанавливаем переключатель к состояние "Выбранный клиент"
                                    radioGroup.clickOnCaption("Выбранные абоненты");
                                  });

                                  it('В поле "Номера абонентов" установлено прежнее значение', function () {
                                    since('В поле "Номера абонентов" установлено не #{expected},а: #{actual}').
                                            expect(abonentsNumbers.getInputText()).toEqual('їЇєЄіІ'+','+phone1+','+phone2);
                                  });

                                  describe('19. После очистки номеров из поля "Номера абонентов" и перемещения фокуса', function () {

                                    var newValue,newStr;

                                    beforeAll(function () {
                                      newValue = abonentsNumbers.getInputText().then(function(str){
                                        newStr = str.split(',')[0];
                                        abonentsNumbers.clear().sendKeys(newStr);
                                      });
                                    });


                                    it('Поле "Номера абонентов" пусто', function () {
                                      since('В поле "Номера абонентов" не пусто, а: #{actual}').
                                              expect(abonentsNumbers.getInputText()).toEqual('');
                                    });

                                    describe('20. После нажатия клавиши "Отменить"', function () {

                                      beforeAll(function () {
                                        lib.getCancelButton().click();
                                      });

                                      it('форма списка закрыта', function () {
                                        since('форма не закрыта').
                                                expect(list.isPresent()).toBe(false);
                                      });

                                      it('открыт список обращений', function () {
                                        since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                                                expect(browser.getCurrentUrl()).toBe(baseUrl + url);
                                      });

                                      // Нет поля абонент => заглушка
                                      it('в списке только обращения с введёнными номерами', function () {
                                        since('Обращения в списке не отфильтрованы').
                                                expect(true).toBe(true);
                                      });

                                      // Нет поля абонент => заглушка
                                      it('в поле "Абонент" быстрого фильтра отображается "їЇєЄіІ,phone1,phone2"', function () {
                                        since('В быстром фильтре отображается не #{expected},а: #{actual}').
                                                expect(true).toBe(true);
                                      });

                                      describe('21. После перехода на закладку фильтра списка обращений "Клиент"', function () {

                                        beforeAll(function () {
                                          // Подождём загрузки формы с кнопками
                                          toolbar.waitReady();

                                          toolbar.getSearchButton().click();
                                          client.click();
                                        });

                                        it('выбранный элемент: "Выбранные абоненты"', function () {
                                          since('Выбранный элемент не "Выбранные абоненты", а "#{actual}"').
                                                  expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранные абоненты");
                                        });

                                        it('В поле "Номера абонентов" установлено прежнее значение', function () {
                                          since('В поле "Номера абонентов" установлено не #{expected},а: #{actual}').
                                                  expect(abonentsNumbers.getInputText()).toEqual('їЇєЄіІ'+','+phone1+','+phone2);
                                        });

                                      });

                                    });

                                  });

                                });

                              });

                            });

                          });

                        });

                      });

                    });

                  });

                });

              });

            });

          });

        });

      });

    });

  });

});

