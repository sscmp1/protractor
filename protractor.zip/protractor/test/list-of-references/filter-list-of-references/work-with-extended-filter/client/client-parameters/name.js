/**
 * @file       name.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Последовательный сценарий на фильтр вкладки клиент списка обращений: "Параметры клиента": "Наименование клиента"
 *
 * @created    [30.09.2015] Lilia Sapurina.
 */

describe('1. После открытия страницы с фильтром, нажатия кнопки "Очистить", перехода на кладку "Клиент" и установки значения фильтрации "Параметры клиента"', function () {

  var lib = require("../../common.js");
  var config = browser.params;
  var url = config.listOfReferencesUrl,
          toolbar,
          list,
          tabs,
          client,
          categoryButton,
          grid,
          radioGroup,
          listOfReferencesValuesNumber;

  // Порядковые номера фильтрующих полей
  var clientNameNum = clientParameters.clientName,
          categoryNum = clientParameters.category,
          featureNum = clientParameters.feature,
          classNum = clientParameters.class,
          statusNum = clientParameters.status,
          filialNum = clientParameters.filial,
          unionNum = clientParameters.union,
          planNum = clientParameters.plan,
          balanceNum = clientParameters.balance;

  // Фильтрующие поля
  var clientName,
          category,
          feature,
          classF,
          status,
          filial,
          union,
          plan,
          balance;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Внутри компонента ps-Grid ищем содержимое колонки "Номер" (1-я колонка)
    grid.getColumn(gridFilter.number).get(0).toPsGrid().waitReady();
    listOfReferencesValuesNumber = grid.getColumn(gridFilter.number);

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();

    // Внутри компонента ps-Toolbar ищем кнопку очистки
    toolbar.getClearButton().click();

    // Внутри компонента ps-Toolbar ищем кнопку с биноклем
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();
    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    // Ищем компонент ps-List на странице
    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();

    // Устанавливаем переключатель к состояние "Параметры клиента"
    radioGroup.clickOnCaption("Параметры клиента");

    clientName = list.getTableValues().get(clientNameNum - 1).toPsList().getInput();
    categoryButton = list.getTableValues().get(categoryNum - 1).toPsList().getDropButton();
    category = list.getTableValues().get(categoryNum - 1).toPsList();
    feature = list.getTableValues().get(featureNum).toPsList();
    classF = list.getTableValues().get(classNum).toPsList();
    status = list.getTableValues().get(statusNum).toPsList();
    filial = list.getTableValues().get(filialNum).toPsList();
    union = list.getTableValues().get(unionNum).toPsList();
    plan = list.getTableValues().get(planNum).toPsList();
    balance = list.getTableValues().get(balanceNum - 1).toPsList().getInput();
  });

  it('поле "Наименование клиента" разрешено', function () {
    since('поле "Наименование клиента" не разрешено').
            expect(clientName.isEnabled()).toBe(true);
  });

  it('поле "Категория" разрешено', function () {
    since('поле "Категория" не разрешено').
            expect(categoryButton.isEnabled()).toBe(true);
  });

  it('поле "Признак" разрешено', function () {
    since('поле "Признак" не разрешено').
            expect(feature.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Класс" разрешено', function () {
    since('поле "Класс" не разрешено').
            expect(classF.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Статус" разрешено', function () {
    since('поле "Статус" не разрешено').
            expect(status.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Филиал" разрешено', function () {
    since('поле "Филиал" не разрешено').
            expect(filial.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Объединение" разрешено', function () {
    since('поле "Объединение" не разрешено').
            expect(union.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Тарифный план" разрешено', function () {
    since('поле "Тарифный план" не разрешено').
            expect(plan.isEnabled()).toBe(true);
  });

  describe("2. После ввода символов  абв <'\"> в поле 'Наименование'", function () {

    beforeAll(function () {
      clientName.click().sendKeys("абв <'\">");
    });

    it('значение в поле отображается корректно', function () {
      since('Значение в поле: "#{actual}"').
              expect(clientName.getInputText()).toEqual("абв <'\">");
    });

    describe("3. После нажатия клавиши 'Отменить'", function () {

      var newListOfReferencesValuesNumber;

      var baseUrl = browser.baseUrl;

      beforeAll(function () {
        lib.getCancelButton().click();
        newListOfReferencesValuesNumber = grid.getColumn(2);
      });

      it('форма списка закрыта', function () {
        since('форма не закрыта').
                expect(list.isPresent()).toBe(false);
      });

      it('открыт список обращений', function () {
        since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                expect(browser.getCurrentUrl()).toBe(baseUrl + url);
      });

      it('cостояние списка соответствует состоянию на начало теста', function () {
        since('Список изменился').
                expect(listOfReferencesValuesNumber.count()).toBe(newListOfReferencesValuesNumber.count());
      });
      //Состояние списка соответствует состоянию на начало теста

      describe('4. После перехода на закладку фильтра списка обращений "Клиент" ', function () {

        beforeAll(function () {
          // Подождём загрузки формы с кнопками
          toolbar.waitReady();

          toolbar.getSearchButton().click();
          client.click();
        });

        it('в поле выбора фильтрации отображается значение "Все клиенты"', function () {
          since('В поле выбора фильтрации отображается не #{expected},а: #{actual}').
                  expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
        });

        describe('5. После выбора способа фильтрации "Параметры клиента" ', function () {

          beforeAll(function () {
            // Устанавливаем переключатель к состояние "Параметры клиента"
            radioGroup.clickOnCaption("Параметры клиента");
          });

          it('Отображается поле "Наименование клиента"', function () {
            since('Поле "Наименование клиента" не отображается').
                    expect(clientName.isDisplayed()).toBe(true);
          });

          it('Поле "Наименование клиента" пустое', function () {
            since('Поле "Наименование клиента" не пустое,а: #{actual}').
                    expect(clientName.getInputText()).toEqual("");
          });

          it('Поле "Наименование клиента" разрешено', function () {
            since('Поле "Наименование клиента" не разрешено').
                    expect(clientName.getInputText().isEnabled()).toBe(true);
          });

          describe("6. После ввода символов  абв <'\"> в поле 'Наименование'", function () {

            beforeAll(function () {
              clientName.click().sendKeys("абв <'\">");
              browser.actions().sendKeys(protractor.Key.TAB).perform();
            });

            it('значение в поле отображается корректно', function () {
              since('Значение в поле: "#{actual}"').
                      expect(clientName.getInputText()).toEqual("абв <'\">");
            });

            describe("7. После копирования символа & из текстового редактора и вставки его в очищенное при помощи клавиши Delete поля 'Наименование клиента'", function () {

              beforeAll(function () {
                // В текстовом редакторе ввести символ & и поместить его в буфер обмена
                clientName.clear();

                // Вставим значение, чтобы скопировать его в буфер обмена
                clientName.sendKeys('&');
                clientName.click();
              });

              it('в поле отображается &', function () {
                since('Значение в поле: "#{actual}"').
                        expect(clientName.getInputText()).toEqual("&");
              });

              describe("8. После нажатия клавиши 'Применить'", function () {
                var newListOfReferencesValuesName,
                        nameQuick;

                var baseUrl = browser.baseUrl;

                beforeAll(function () {
                  lib.getApplyButton().click();
                  // Извлечём значения из колонки "Имя клиента"
                  newListOfReferencesValuesName = grid.getColumn(gridFilter.clientName);
                  nameQuick = grid.getQuickFilter(gridFilter.clientName);
                });

                it('форма списка закрыта', function () {
                  since('форма не закрыта').
                          expect(list.isPresent()).toBe(false);
                });

                it('открыт список обращений', function () {
                  since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                          expect(browser.getCurrentUrl()).toBe(baseUrl + url);
                });

                //Заглушка
                it('в списке - только обращения клиентов, чье имя содержит символ &', function () {
                  since('Список отфильтрован неверно').
                          expect(newListOfReferencesValuesName.getText()).toContain("&");
                });

                it('в поле "Имя клиента" быстрого фильтра отображается "&"', function () {
                  since('В поле "Имя клиента" быстрого фильтра не "&",а: #{actual}').
                          expect(nameQuick.getInputText()).toEqual("&");
                });

                describe('9. После перехода на закладку фильтра списка обращений "Клиент"', function () {

                  beforeAll(function () {
                    toolbar.waitReady();
                    toolbar.getSearchButton().click();
                    client.click();
                  });

                  it('в поле выбора фильтрации отображается значение "Параметры клиента"', function () {
                    since('В поле выбора фильтрации отображается не #{expected},а: #{actual}').
                            expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
                  });

                  it('в поле "Наименование клиента" отображается &', function () {
                    since('В поле "Наименование клиента" не "&", а: "#{actual}"').
                            expect(clientName.getInputText()).toEqual("&");
                  });

                  describe('10. После выделения и удаления значения в поле "Наименование клиента"', function () {

                    beforeAll(function () {
                      clientName.click();
                      clientName.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "a"));
                      clientName.sendKeys(protractor.Key.DELETE);
                    });

                    it('поле "Наименование клиента" пусто', function () {
                      since('Поле "Наименование клиента" не пусто, в нём: "#{actual}"').
                              expect(clientName.getInputText()).toEqual("");
                    });

                    describe("11. После ввода в текстовом редакторе имя клиента [КЛИЕНТ1] и дополнения его до 65 символов и копирования 'Наименование клиента'", function () {

                      // Пока нет колонки "Имя клиента" генерируем имя самостоятельно
                      var client1 = "їЇєЄіІ";

                      beforeAll(function () {
                        client1 = client1 + create_string_by_length(65 - client1.length, 'a');
                        clientName.click().clear().sendKeys(client1);
                      });

                      it('в поле выбора фильтрации отображается значение "Параметры клиента"', function () {
                        since('В поле выбора фильтрации отображается не #{expected},а: #{actual}').
                                expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
                      });

                      it('в поле "Наименование клиента" отображается первые 64 символа имени клиента', function () {
                        since('В поле "Наименование клиента" отображается #{expected},а: #{actual}').
                                expect(clientName.getInputText()).toEqual(client1.substring(0,64));
                      });

                      describe("12. После удаления с помощью Backspace лишние символы, оставив только украинские (їЇєЄіІ) и последовательной устновки полей 'Выбранный клиент', 'Параметры клиента' в поле выбора способа фильтрации", function () {

                        beforeAll(function () {
                          clientName.click();
                          // Выделим значение в поле
                          clientName.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "a"));
                          // Очистим при помощи Backspace
                          clientName.sendKeys(protractor.Key.BACKSPACE);
                          clientName.click().clear().sendKeys("їЇєЄіІ");
                        });

                        it('поле "Наименование клиента" пусто', function () {
                          since('В поле "Наименование клиента" не пусто, а: #{actual}').
                                  expect(clientName.getInputText()).toEqual("їЇєЄіІ");
                        });

                        describe("13. После нажатия клавиши 'Применить'", function () {

                          beforeAll(function () {
                            lib.getApplyButton().click();

                          });

                          it('форма списка закрыта', function () {
                            since('форма не закрыта').
                                    expect(list.isPresent()).toBe(false);
                          });

                          it('открыт список обращений', function () {
                            since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                                    expect(browser.getCurrentUrl()).toBe(baseUrl + url);
                          });

                          //Заглушка
                          it('в списке - только обращения клиентов, чье имя содержит символы їЇєЄіІ', function () {
                            since('Список отфильтрован неверно').
                                    expect(newListOfReferencesValuesName.getText()).toContain("&");
                          });

                          it('в поле "Имя клиента" быстрого фильтра отображается "їЇєЄіІ"', function () {
                            since('В поле "Имя клиента" быстрого фильтра не "їЇєЄіІ",а: #{actual}').
                                    expect(nameQuick.getInputText()).toEqual("їЇєЄіІ");
                          });

                          describe('14. После перехода на закладку фильтра списка обращений "Клиент"', function () {

                            beforeAll(function () {
                              // Подождём загрузки формы с кнопками
                              toolbar.waitReady();
                              toolbar.getSearchButton().click();
                              client.click();
                            });

                            it('в поле выбора фильтрации отображается значение "Параметры клиента"', function () {
                              since('В поле выбора фильтрации отображается не #{expected},а: #{actual}').
                                      expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
                            });

                            it('в поле "Наименование клиента" отображается їЇєЄіІ', function () {
                              since('В поле "Наименование клиента" не "їЇєЄіІ", а: "#{actual}"').
                                      expect(clientName.getInputText()).toEqual("їЇєЄіІ");
                            });

                            describe('15. После последовательной установки значений "Выбранный клиент" и "Параметры клиента" в поле "Выбор способа фильтрации"', function () {

                              beforeAll(function () {
                                // Устанавливаем переключатель к состояние "Выбранный клиент"
                                radioGroup.clickOnCaption("Выбранный клиент");

                                // Устанавливаем переключатель к состояние "Параметры клиента"
                                radioGroup.clickOnCaption("Параметры клиента");
                              });

                              it('поле "Наименование клиента" пусто', function () {
                                since('В поле "Наименование клиента" не пусто, а: "#{actual}"').
                                        expect(clientName.getInputText()).toEqual("");
                              });

                              describe('16. После установки в поле "Категория" значения "Все категории", ввода поле "Баланс" значения 0, перетаскивания этого значения в поле "Наименование клиента"', function () {

                                beforeAll(function () {

                                  clientName.click();
                                  clientName.sendKeys('0');
                                });

                                // Заглушка
                                it('В поле отображается новое значение', function () {
                                  since('В поле "Наименование клиента" отображается не #{expected},а: #{actual}').
                                          expect(clientName.getInputText()).toEqual("0");
                                });

                                describe('17. После выбора способа фильтрации "Выбранный клиент" и нажатия кнопки "Отменить" ', function () {

                                  beforeAll(function () {
                                    // Устанавливаем переключатель к состояние "Выбранный клиент"
                                    radioGroup.clickOnCaption("Выбранный клиент");

                                    // Нажмём кнопку отмены
                                    lib.getCancelButton().click();
                                  });

                                  it('форма списка закрыта', function () {
                                    since('форма не закрыта').
                                            expect(list.isPresent()).toBe(false);
                                  });

                                  it('открыт список обращений', function () {
                                    since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                                            expect(browser.getCurrentUrl()).toBe(baseUrl + url);
                                  });

                                  it('состояние списка не изменено', function () {
                                    since('Список отфильтрован неверно').
                                            expect(newListOfReferencesValuesName.getText()).toContain("?");
                                  });

                                  describe('18. После перехода на закладку фильтра списка обращений "Клиент"', function () {

                                    beforeAll(function () {
                                      // Подождём загрузки формы с кнопками
                                      toolbar.waitReady();

                                      toolbar.getSearchButton().click();
                                      client.click();
                                    });

                                    it('в поле выбора фильтрации отображается значение "Параметры клиента"', function () {
                                      since('В поле выбора фильтрации отображается не #{expected},а: #{actual}').
                                              expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
                                    });

                                    it('в поле "Наименование клиента" отображается їЇєЄіІ', function () {
                                      since('В поле "Наименование клиента" не "їЇєЄіІ", а: "#{actual}"').
                                              expect(clientName.getInputText()).toEqual("їЇєЄіІ");
                                    });
                                  });
                                });
                              });
                            });
                          });
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});