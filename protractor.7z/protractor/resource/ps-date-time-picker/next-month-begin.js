/**
 * @file       next-month-begin.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка всех полей из выпадающего списка: "Начало следующего месяца"
 *
 * @created    [07.08.2015] Lilia Sapurina.
 */

describe('При выборе поля из выпадающего списка "начало следующего месяца"', function () {

  var config = browser.params,
      url = config.psDateTimePickerUrl,
      datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();

    datePicker.getField().clear().sendKeys('Начало следующего месяца');
    datePicker.getCalendarButton().click();

    // Найдём на календаре отмеченный день и кликнем на него
    datePicker.getSelectedValue().click();
  });

  it('в календаре устанавливается текущее время начала следующего месяца', function () {
    since('Значение календаря не #{expected},а: #{actual}').
            expect(datePicker.getField().getInputText()).toEqual(next_month_begin());
  });

});