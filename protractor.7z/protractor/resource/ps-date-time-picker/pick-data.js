/**
 * @file       pick-data.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При нажатии на дату в календаре дата в поле календаря меняется и совпадает с выбранной (дата текущего месяца)
 *
 * @created    [07.08.2015] Lilia Sapurina.
 */

describe('При нажатии на дату в календаре', function () {

  var config = browser.params,
          url = config.psDateTimePickerUrl,
          datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();

    datePicker.getCalendarButton().click();

    // Н.у.о. 13 день (т.е.дата текущего месяца)
    datePicker.getCalendarDates().get(13).click();
    datePicker.getCalendarButton().click();
  });

  it('в поле календаря меняется и совпадает с выбранной', function () {

    datePicker.getField().getInputText().then(function (value) {

      // Парсим поле календаря
      var parseCalendarField = value.split('.');
      // Берём день из текущего месяца
      var dd = datePicker.getCalendarDates().get(13).getText();
      // Проверяем совпадение дней
      expect(dd).toEqual(parseCalendarField[0]);

      datePicker.getMonthYear().getText().then(function (m_y) {

        datePicker.getCalendarDates().get(13).click();
        // Парсим поле с месяцем и годом
        var parseMonthYear = m_y.split(' ');
        var yyyy = parseMonthYear[1];
        // Переведём название месяца в его номер (нумерация с нуля)
        var month = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь',
          'Ноябрь', 'Декабрь'];
        var mm = month.indexOf(parseMonthYear[0]) + 1;

        if (mm < 10) {
          mm = '0' + mm;
        }

        since('Значение месяца календаря не #{expected},а: #{actual}').
           expect(mm).toEqual(parseCalendarField[1]);

        // Ещё раз парсим, т.к. там ещё и время
        since('Значение года календаря не #{expected},а: #{actual}').
            expect(yyyy).toEqual(parseCalendarField[2].split(' ')[0]);

      });
    });

  });
});