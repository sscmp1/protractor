/**
 * @file       scroll-time.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При движении перемещении элемента scroll время остаётся в интервале от 00:00 до 23:59
 *
 * @created    [04.08.2015] Lilia Sapurina.
 */

describe('При передвижении скроллера', function () {

  var config = browser.params,
      moveDirection = datePickerValue.moveDirection,
      moveSize = datePickerValue.moveSize,
      deferred = protractor.promise.defer(),
      url = config.psDateTimePickerUrl,
      datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();

    datePicker.getCalendarButton().click();
  });

  it('время остаётся в интервале от 00:00 до 23:59', function () {

    // Перемещаем scroller в зависимости от параметра move_direction вправо или влево
    if (datePicker.getScroller().isPresent()) {
      datePicker.getScroller().dragAndDrop(moveSize * moveDirection,0);

      since('Время не остаётся в интервале от 00:00 до 23:59 , а: #{actual}').
          expect(datePicker.getTimeUnderScroll().dateInInterval('23:59','00:00')).toBe(true);
    }
    else {
      deferred.reject('scroller не представлен');
    }

  });
});