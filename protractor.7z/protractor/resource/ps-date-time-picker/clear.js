/**
 * @file       clear.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При нажатии на кнопку с корзиной содержимое поля календаря очищается
 *
 * @created    [05.08.2015] Lilia Sapurina.
 */

describe('При нажатии на кнопку с корзиной', function () {

  var config = browser.params,
      url = config.psDateTimePickerUrl,
      datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();
    datePicker.getClearButton().click();
  });

  it('содержимое поля календаря очищается', function () {
    since('Содержимое календаря не очищено. В поле: #{actual}').
      expect(datePicker.getField().getInputText()).toEqual('');
  });
});