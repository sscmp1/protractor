/**
 * @file       current-date.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При открытии формы в поле календаря установлена текущая дата и время
 *
 * @created    [04.08.2015] Lilia Sapurina.
 */

describe('При открытии страницы', function () {

  var config = browser.params,
          url = config.psDateTimePickerUrl,
          datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();
  });

  it('в поле находится текущая дата и время', function () {
    since('В поле календаря не #{expected},а: #{actual}').
      expect(datePicker.getField().getInputText()).toEqual(today());
  });
});