/**
 * @file       click.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При нажатии на кнопку календарь открывается
 *
 * @created    [31.07.2015] Lilia.Sapurina.
 */

describe('При нажатии на кнопку', function () {

  var config = browser.params,
          url = config.psDateTimePickerUrl,
          datePicker;

  beforeAll(function(){
    browser.get(url);

    datePicker = psDateTimePicker(by.Name("DateTimePicker1","td"));
    datePicker.waitReady();
    datePicker.getCalendarButton().click();
  });

  it('календарь открывается', function () {
    since('Календарь не открыт').
      expect(datePicker.getCalendar().isDisplayed()).toBe(true);
  });
});