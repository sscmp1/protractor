﻿/**
 * @file       login_test.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Marina Peunkova Marina.Peunkova@billing.ru.
 * @fileoverview Вход в окружение SBMS
 *
 * @created    [11.11.2015] Marina Peunkova.
 */

describe('angularjs homepage', function() {
  it('Ожидание', function() {	
    browser.get('http://srv2-x64rh5-01:3333/ps/sbms/shell.html?shell_no_start_window=1&shell_login=vclir&shell_password=1111');
	browser.executeScript("sbms_shell_context_set('ACCOUNT','73');");
	browser.executeScript("icms.go('SBMS_S_CLI', 'CreateCustomer', {},0);");	
	browser.waitForAngular();
	//element(by.css('[ng-click="Save()"]'));
	element(by.id('gender'));	
	var elementBusy=by.xpath('//*[@id="shell_modal_busy"]'); //special Busy element

	console.log('waiting for Busy');
	browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementBusy).isPresent().then(function (isPresent) {
            deferred.fulfill(isPresent);
        });
    return deferred.promise;
    });
	
	console.log('waiting for Busy disappeared');
	browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementBusy).isPresent().then(function (isPresent) {
            deferred.fulfill(!isPresent);
        });
    return deferred.promise;
    });	
	element(by.model('customerDataForm.name')).sendKeys('Иванов Иван Семенович');
	element(by.name('phone')).sendKeys('9817235595');
	element(by.name('email')).sendKeys('marina.peunkova@gmail.com');
	element(by.name('deliveryPhone')).sendKeys('5555555');
	element(by.name('deliveryFax')).sendKeys('666666');
	element(by.linkText('Создать')).click();
  });
});

