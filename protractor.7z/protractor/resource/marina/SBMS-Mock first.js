﻿/**
 * @file       login_test.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Marina Peunkova Marina.Peunkova@billing.ru.
 * @fileoverview Вход в окружение SBMS
 *
 * @created    [11.11.2015] Marina Peunkova.
 */

describe('angularjs homepage', function() {
var HttpBackend = require('httpbackend');
    beforeEach(function() {
        backend = new HttpBackend(browser);
    });
    afterEach(function() {
        backend.clear();
    });
  it('Ожидание', function() {	 
	
	//backend.whenGET('http://srv2-x64rh5-01:3333/OAPI/v1/customers/74').respond('{}');
	//backend.whenGET(/customers/).respond('{"customerId":74,"name":"autoauto","juralType":{"juralTypeId":2,"name":"Физическое лицо"},"status":{"customerStatusId":1,"name":"До оплаты"},"category":{"customerCategoryId":2,"name":"Кредитный"},"customerType":{"customerTypeId":1,"name":"Коммерческий"},"branch":{"branchId":1,"name":"Приморский филиал","macroRegion":null},"customerClass":{"customerClassId":1,"name":"Нормальный","isINNRequired":false},"accountNumber":"74","mainContract":null,"comment":"747474747474","language":{"languageId":1,"name":"Русский"},"activationArea":null,"department":null,"registrationCategory":{"registrationCategoryId":3,"name":"Данные подтверждены"},"isExtendedBillingSupported":true,"VIPGroupNames":null,"balances":{"currentBalance":0,"commonBalance":0,"conditionalBalance":0,"rtBalance":null,"mainBillTypeBalance":null,"mainBillTypeConditionalBalance":null},"contracts":[],"extendedStatuses":{"isRtControlEnabled":false,"isLcControlEnabled":false,"lcStatus":null},"personalData":{"secretWord":null,"mainContactPerson":{"phone":"2","fax":"4747474747474","email":"2","name":"Шевцова Анастасия Андреевна"},"residentType":null,"birthDate":null,"registrationAddress":{"addressId":null,"addressAsString":"Санкт-Петербург","appartment":null,"addressZIP":null,"house":null,"block":null,"street":null,"city":{"cityAsText":null,"cityFromDictionary":{"cityId":159,"name":"Санкт-Петербург"}},"districtOfCity":null,"province":null,"districtOfProvince":null,"country":{"country":{"countryId":1,"name":"Россия"}}},"factAddress":{"addressId":null,"addressAsString":"Владивосток","appartment":null,"addressZIP":null,"house":null,"block":null,"street":null,"city":{"cityAsText":null,"cityFromDictionary":{"cityId":148,"name":"Владивосток"}},"districtOfCity":null,"province":null,"districtOfProvince":null,"country":{"country":{"countryId":1,"name":"Россия"}}},"birthPlace":null,"gender":null,"identityDocument":{"docType":{"identityDocTypeId":6,"name":"Удостоверение личности","docNumberRegExp":null,"docSeriesRegExp":null},"number":"2","series":"2","issuedBy":"2","issueDate":"2015-10-06T00:00:00"},"INN":null,"deliveryInfo":{"name":"Шаблон Приморский","legalForm":null,"deliveryType":{"deliveryTypeId":3,"name":"Не доставлять","isEmailRequired":false},"addressStatus":{"deliveryAddressStatusId":1,"name":"Не проверен"},"deliveryZone":null,"changeAddressReason":{"changeAddressReasonId":1,"name":"Информация клиента"},"comment":"autuautoauto","isSMSNotificationEnabled":false,"fax":null,"phone":null,"email":null,"contactPerson":null,"customAttributes":[]}},"financialInfo":{"billingGroup":{"billingGroupId":1,"name":"Биллинговая группа 1"},"taxes":[{"tax":{"taxId":1,"name":"НДС","isChangeStartDateSupported":false,"isMandatory":false},"startDate":"2014-06-05T23:59:59","endDate":"2999-12-31T00:00:00"},{"tax":{"taxId":4,"name":"ПФ","isChangeStartDateSupported":true,"isMandatory":true},"startDate":"2015-10-08T00:00:00","endDate":"2999-12-31T00:00:00"}],"paymentProfile":{"recipientAccount":{"bankAccountId":1,"bankAccount":"4070281014589657775334777777777777777777777777777777777777777777777777777777777777777777777777777777","accountForPrintingInvoice":"ВТБ р\/с 40702810145896555334\nБИК 042567904 \nк\/с 30101810000000000334","subaccounts":[]},"isCashPaymentEnabled":true}},"association":{"isMainCustomer":false,"isAddressInfoSupported":false,"association":null},"customAttributes":[]}');
    //backend.whenGET('http://srv2-x64rh5-01:3333/OAPI/v1/customers/74').respond('{
		"customerId":74,"name":"autoauto","juralType":{"juralTypeId":2,"name":"Физическое лицо"},"status":{"customerStatusId":1,"name":"До оплаты"},"category":{"customerCategoryId":2,"name":"Кредитный"},"customerType":{"customerTypeId":1,"name":"Коммерческий"},"branch":{"branchId":1,"name":"Приморский филиал","macroRegion":null},"customerClass":{"customerClassId":1,"name":"Нормальный","isINNRequired":false},"accountNumber":"74","mainContract":null,"comment":"747474747474","language":{"languageId":1,"name":"Русский"},"activationArea":null,"department":null,"registrationCategory":{"registrationCategoryId":3,"name":"Данные подтверждены"},"isExtendedBillingSupported":true,"VIPGroupNames":null,"balances":{"currentBalance":0,"commonBalance":0,"conditionalBalance":0,"rtBalance":null,"mainBillTypeBalance":null,"mainBillTypeConditionalBalance":null},"contracts":[],"extendedStatuses":{"isRtControlEnabled":false,"isLcControlEnabled":false,"lcStatus":null},"personalData":{"secretWord":null,"mainContactPerson":{"phone":"2","fax":"4747474747474","email":"2","name":"Шевцова Анастасия Андреевна"},"residentType":null,"birthDate":null,"registrationAddress":{"addressId":null,"addressAsString":"Санкт-Петербург","appartment":null,"addressZIP":null,"house":null,"block":null,"street":null,"city":{"cityAsText":null,"cityFromDictionary":{"cityId":159,"name":"Санкт-Петербург"}},"districtOfCity":null,"province":null,"districtOfProvince":null,"country":{"country":{"countryId":1,"name":"Россия"}}},"factAddress":{"addressId":null,"addressAsString":"Владивосток","appartment":null,"addressZIP":null,"house":null,"block":null,"street":null,"city":{"cityAsText":null,"cityFromDictionary":{"cityId":148,"name":"Владивосток"}},"districtOfCity":null,"province":null,"districtOfProvince":null,"country":{"country":{"countryId":1,"name":"Россия"}}},"birthPlace":null,"gender":null,"identityDocument":{"docType":{"identityDocTypeId":6,"name":"Удостоверение личности","docNumberRegExp":null,"docSeriesRegExp":null},"number":"2","series":"2","issuedBy":"2","issueDate":"2015-10-06T00:00:00"},"INN":null,"deliveryInfo":{"name":"Шаблон Приморский","legalForm":null,"deliveryType":{"deliveryTypeId":3,"name":"Не доставлять","isEmailRequired":false},"addressStatus":{"deliveryAddressStatusId":1,"name":"Не проверен"},"deliveryZone":null,"changeAddressReason":{"changeAddressReasonId":1,"name":"Информация клиента"},"comment":"7474747474","isSMSNotificationEnabled":false,"fax":null,"phone":null,"email":null,"contactPerson":null,"customAttributes":[]}},"financialInfo":{"billingGroup":{"billingGroupId":1,"name":"Биллинговая группа 1"},"taxes":[{"tax":{"taxId":1,"name":"НДС","isChangeStartDateSupported":false,"isMandatory":false},"startDate":"2014-06-05T23:59:59","endDate":"2999-12-31T00:00:00"},{"tax":{"taxId":4,"name":"ПФ","isChangeStartDateSupported":true,"isMandatory":true},"startDate":"2015-10-08T00:00:00","endDate":"2999-12-31T00:00:00"}],"paymentProfile":{"recipientAccount":{"bankAccountId":1,"bankAccount":"4070281014589657775334777777777777777777777777777777777777777777777777777777777777777777777777777777","accountForPrintingInvoice":"ВТБ р\/с 40702810145896555334\nБИК 042567904 \nк\/с 30101810000000000334","subaccounts":[]},"isCashPaymentEnabled":true}},"association":{"isMainCustomer":false,"isAddressInfoSupported":false,"association":null},"customAttributes":[]}');
       
	//backend.whenGET('http://srv2-x64rh5-01:3333/OAPI/v1/customers/74').respond('{}');
	
      backend.when('GET','http://srv2-x64rh5-01:3333/OAPI/v1/customers/74').respond('{}');
    browser.get('http://srv2-x64rh5-01:3333/ps/sbms/shell.html?shell_no_start_window=1&shell_login=vclir&shell_password=1111');
	
	//browser.addMockModule('httpBackEndMock', backEndMocks.build([backEndMocks.w7Restaurants]));
	browser.sleep(200);
	browser.executeScript("icms.go('SBMS_S_CLI', 'CliCardTabs', {CLNT_ID:74},0);");	
	browser.waitForAngular();
	element(by.css('[ng-click="Save()"]'));
	element(by.id('gender'),100);
	
	var elementToFind=by.xpath('//*[@id="shell_modal_busy"]'); //special Busy element

	console.log('waiting for Busy');
	browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementToFind).isPresent().then(function (isPresent) {
            deferred.fulfill(isPresent);
        });
    return deferred.promise;
    });
	
	console.log('waiting for Busy disappeared');
	browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementToFind).isPresent().then(function (isPresent) {
            deferred.fulfill(!isPresent);
        });
    return deferred.promise;
    });
	browser.sleep(1000);
    browser.close();
    console.log('window is closed');	

  });
  
 
});






