﻿/**
 * @file       login_test.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Marina Peunkova Marina.Peunkova@billing.ru.
 * @fileoverview Вход в окружение SBMS
 *
 * @created    [11.11.2015] Marina Peunkova.
 */

describe('angularjs homepage', function() {


 function untilElementIsPresentedNotPresented(elementDesired){	 
  browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementDesired).isPresent().then(function (isPresent) {
            deferred.fulfill(isPresent);
        });
    return deferred.promise;
    });
	browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementDesired).isPresent().then(function (isPresent) {
            deferred.fulfill(!isPresent);
        });
    return deferred.promise;
    });	
  }
  function untilElementIsPresented(elementDesired){
	  browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementDesired).isPresent().then(function (isPresent) {
        deferred.fulfill(isPresent);
        });
    return deferred.promise;
    });	  
  } 
   function untilElementIsDisplayed(elementDesired){
	  browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementDesired).isDisplayed().then(function (isDisplayed) {
        deferred.fulfill(isDisplayed);
        });
    return deferred.promise;
    });	  
  } 
   function untilElementIsNotPresented(elementDesired){
	  browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementDesired).isPresent().then(function (isPresent) {
            deferred.fulfill(!isPresent);
        });
    return deferred.promise;
    });
  } 

  it('Ожидание', function() {	
    
    browser.get(browser.baseUrl);	
    //browser.get('http://srv2-x64rh5-01:11111/ps/sbms/shell.html?shell_no_start_window=1&shell_login=vclir&shell_password=1111');
	browser.sleep(200);
	browser.executeScript("icms.go('SBMS_S_CLI','CreateCustomer', {},0);");	
	browser.waitForAngular();	
	
	var elB=by.xpath('//*[@id="shell_modal_busy"]'); //special Busy element
	//browser.wait(element(by.xpath('//*[@id="shell_modal_busy"]'))).isPresent;
	untilElementIsPresentedNotPresented(elB);
	//untilElementIsPresented(elB);
	//untilElementIsNotPresented(elB);
	var customerName='Автоматов Автомат Автоматович'
	var elementCustomerName=element(by.model('customerDataForm.name'));;
	var elementDeliveryName=element(by.model('customerDataForm.personalData.deliveryInfo.name'));	
	elementCustomerName.clear();
	elementCustomerName.sendKeys(customerName); //заполнить имя клиента
	browser.sleep(200);
	element(by.model('customerDataForm.comment')).click();	//установить фокус на любое другое поле	
	browser.sleep(200);
	expect(elementDeliveryName.getAttribute("value")).toEqual(elementCustomerName.getAttribute("value")); //проверить, что имя в доставке = имени клиента
	/*
	element(by.linkText('Создать')).click();
	console.log('push Create');
	var elementPost=by.xpath('//*[@class="ps-dialog n-popup ng-scope"]'); //"post"-form	
	untilElementIsPresented(elementPost);
	
	element(by.linkText('На карточку клиента')).click();
	var elementPost=by.xpath('//*[@class="ps-dialog n-popup ng-scope"]'); //"post"-form	
	untilElementIsNotPresent(elB);
	*/
	browser.close();
  });
 
});
