﻿/**
 * @file       login_test.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Marina Peunkova Marina.Peunkova@billing.ru.
 * @fileoverview Вход в окружение SBMS
 *
 * @created    [11.11.2015] Marina Peunkova.
 */

describe('angularjs homepage', function() {
  it('Ожидание', function() {	
    //var configmock = require('httpmocker').config;
    browser.get('http://srv2-x64rh5-01:3333/ps/sbms/shell.html?shell_no_start_window=1&shell_login=vclir&shell_password=1111');	
	browser.executeScript("icms.go('SBMS_S_CLI', 'CreateCustomer', {},0);");	
	browser.waitForAngular();
	
	var elementBusy=by.xpath('//*[@id="shell_modal_busy"]'); //special Busy element
	console.log('waiting for Busy');
	untilElementIsNotPresent(elementBusy)	
	
	var elementTemp;
	elementTemp=element(by.model('customerDataForm.name'));
	elementTemp.clear();
	elementTemp.sendKeys('Автоматов Иван Семенович');
	
	elementTemp=element(by.name('phone'));
	elementTemp.clear();	
	elementTemp.sendKeys('9817235595');
	
	elementTemp=element(by.name('email'));
	elementTemp.clear();
	elementTemp.sendKeys('marina.peunkova@gmail.com');
	
	elementTemp=element(by.name('deliveryPhone'));
	elementTemp.clear();
	elementTemp.sendKeys('1767845');
	
	elementTemp=element(by.name('deliveryFax'));
	elementTemp.clear();
	elementTemp.sendKeys('89110116633');
	
	console.log('Creation');
	//element(by.linkText('Создать')).click();
	
	console.log('push Create');
	var elementPost=by.xpath('//*[@class="ps-dialog n-popup ng-scope"]'); //"post"-form	
	untilElementIspresented(elementPost);
	
	element(by.linkText('На карточку клиента')).click();
	untilElementIsNotPresent(elementBusy);
	browser.sleep(5000);
  });
  function untilElementIsNotPresent(elementDesired){
  browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementDesired).isPresent().then(function (isPresent) {
            deferred.fulfill(isPresent);
        });
    return deferred.promise;
    });
	browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementDesired).isPresent().then(function (isPresent) {
            deferred.fulfill(!isPresent);
        });
    return deferred.promise;
    });	
  }
  function untilElementIspresented(elementDesired){
	  browser.wait(function() {
        var deferred = protractor.promise.defer();
        element(elementDesired).isPresent().then(function (isPresent) {
        deferred.fulfill(isPresent);
        });
    return deferred.promise;
    });	  
  }
});
