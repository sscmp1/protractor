/**
 * @file       arrow-show.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Cтрелка показывается
 *
 * @created    [31.07.2015] Lilia.Sapurina.
 */

describe('После нажатия на заголовок колонки', function () {

  var config = browser.params;
  var url = config.psGridUrl,
          grid,
          column;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.xpath(psGridXpath));
    grid.waitReady();

    column = grid.getColumnHead(2);
    column.click();
  });

  it('демонстрируется стрелка', function () {

   since('Колонка не отфильтрована по убыванию. Должно быть: #{expected}, на странице: #{actual}').
         expect(column.getArrow().isPresent()).toBe(true);
  });
});