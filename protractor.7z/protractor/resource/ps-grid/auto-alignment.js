/**
 * @file       ps-grid_auto_alignment.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При выборе пункта "Автовыравнивание" заголовки колонок выравниваются относительно их содержимого (аналогично двойному клику)
 *
 * @created    [03.08.2015] Lilia Sapurina.
 */

describe('list-of-references_auto_alignment', function() {

  var config = browser.params;

  // Глобальные переменные
  var column_number = config.column_number;
  var columns_xpath = config.columns_xpath;
  var column_body_xpath = config.column_body_xpath_grid;

  // Поиск по локатору
  var all_columns = element.all(by.xpath(columns_xpath));
  var current_column_body = element.all(by.xpath(column_body_xpath));

  var current_column = all_columns.get(column_number - 1);
  var current_column_body_first_elem = current_column_body.get(0);

  beforeEach(function(){
    browser.get('sbms/shell.html?shell_login=CMS_HAS&shell_password=qwerty&shell_modus=t&shell_modus=c');
    browser.executeScript("icms.go('WEB_INQ_PROC', 'InquiryList', null, 0)");
  });

  it('после клика на пункт "автовыравнивание" заголовок колонки выравнивается относительно его содержимого', function() {

    // Вычислим размеры колонки до автовыравнивания
    var current_column_height = 0;
    var current_column_width = 0;
    current_column.getSize().then(function (navDivSize) {
      current_column_height = navDivSize.height;
      current_column_width =  navDivSize.width;
    });

    // Кликнем правой кнопкой мыши (путём эмулирования нажатия клавиши вниз дойдём до нужного пункта и нажмём enter)
    browser.actions().mouseMove(current_column).click(protractor.Button.RIGHT).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.ENTER).perform();

    // Вычислим размеры колонки после автовыравнивания
    var new_current_column_height = 0;
    var new_current_column_width = 0;
    current_column.getSize().then(function (navDivSize) {
      new_current_column_height = navDivSize.height;
      new_current_column_width =  navDivSize.width;

      // Высота колонки должна остаться прежней
      expect(new_current_column_height).toEqual(current_column_height);
    });

    // Если у колонки в теле есть элементы, то проверяем, что текст после двойного клика не скрывается (его размер <= нового размера колонки)
    if (current_column_body_first_elem.isPresent()) {
      var current_column_body_height = 0;
      var current_column_body_width = 0;

      current_column_body.each(function (elm) {
        current_column_body_height = 0;
        current_column_body_width = 0;
        return elm.getSize().then(function (navDivSize) {
          current_column_body_height = navDivSize.height;
          current_column_body_width =  navDivSize.width;

          expect(current_column_body_height <= new_current_column_height).toBe(true);
          expect(current_column_body_width <= new_current_column_width).toBe(true);
        });
      });
    }
    else {
      expect(true).toBe(false);
    }

  });

});