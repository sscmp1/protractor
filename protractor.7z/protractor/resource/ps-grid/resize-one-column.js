/**
 * @file       ps-grid_resize_one_column.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что колонки можно растягивать и сжимать (остальные колонки при этом размера не меняют)
 *
 * @created    [31.07.2015] Lilia.Sapurina.
 */

describe('ps-grid_resize_one_column', function () {

  var config = browser.params;

  // Глобальные переменные
  var columns_xpath = config.columns_xpath;
  var resizer_xpath = config.resizer_xpath;
  var stretch_value = config.stretch_value;
  var column_number = config.column_number;

  // Поиск по локатору
  var column_resizer = element(by.xpath(resizer_xpath));
  var all_columns = element.all(by.xpath(columns_xpath));

  beforeEach(function(){
    browser.get('sbms/shell.html?shell_login=CMS_HAS&shell_password=qwerty&shell_modus=t&shell_modus=c');
    browser.executeScript("icms.go('WEB_INQ_PROC', 'InquiryList', null, 0)");
  });

  it('после растяжения заголовка остальные колонки должны сохранить свои размеры', function () {
    // Сохраним размеры заголовков до растяжения (всх, кроме растягиваемой колонки)
    var all_columns_height_before_click = all_columns.filter(function (elem, index) {
      if (index != column_number) {
        return elem;
      }
    }).getSize();

    var column_resizer_height = 0;
    var column_resizer_width = 0;
    column_resizer.getSize().then(function (navDivSize) {
      column_resizer_height = navDivSize.height;
      column_resizer_width = navDivSize.width;

      var column_resizer_x = 0;
      var column_resizer_y = 0;

      column_resizer.getLocation().then(function (navDivLocation) {
        column_resizer_x = navDivLocation.x;
        column_resizer_y = navDivLocation.y;

        // Нажать нужно на середину элемента - ресайзера
        var x1 = column_resizer_x + column_resizer_width / 2;
        var x2 = column_resizer_y + column_resizer_height / 2;

        browser.actions().dragAndDrop({x: x1, y: x2}, {x: stretch_value, y: 0}).perform();
      });
    });

    // Сохраним размеры заголовков после растяжения (всх, кроме растягиваемой колонки)
    var all_columns_height_after_click = all_columns.filter(function (elem, index) {
      if (index != column_number) {
        return elem;
      }
    }).getSize();

    // Сравниваем высоты и длины до и после растяжения
    expect(all_columns_height_before_click.height).toEqual(all_columns_height_after_click.height);
    expect(all_columns_height_before_click.width).toEqual(all_columns_height_after_click.width);

  });

});