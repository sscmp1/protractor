/**
 * @file       ps-grid_double_click.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при двойном клике колонка приобретает размер равный содержащемуся в нём тексту
 *
 * @created    [03.08.2015] Lilia Sapurina.
 */

describe('ps-grid_double_click', function () {

  var config = browser.params;

  // Глобальные переменные
  var columns_xpath = config.columns_xpath;
  var resizer_xpath = config.resizer_xpath;
  var column_body_xpath = config.column_body_xpath_grid;
  var column_number = config.column_number;

  // Поиск по локатору
  var all_columns = element.all(by.xpath(columns_xpath));
  var column_resizer = element(by.xpath(resizer_xpath));
  var current_column_body = element.all(by.xpath(column_body_xpath));

  var current_column = all_columns.get(column_number - 1);
  var current_column_body_first_elem = current_column_body.get(0);

  beforeEach(function(){
    browser.get('sbms/shell.html?shell_login=CMS_HAS&shell_password=qwerty&shell_modus=t&shell_modus=c');
    browser.executeScript("icms.go('WEB_INQ_PROC', 'InquiryList', null, 0)");
  });

  it('после двойного клика колонка принимает размер текста', function () {

    var current_column_height = 0;
    var current_column_width = 0;
    current_column.getSize().then(function (navDivSize) {
      current_column_height = navDivSize.height;
      current_column_width = navDivSize.width;
    });


    var column_resizer_height = 0;
    var column_resizer_width = 0;
    column_resizer.getSize().then(function (navDivSize) {
      column_resizer_height = navDivSize.height;
      column_resizer_width = navDivSize.width;

      var column_resizer_x = 0;
      var column_resizer_y = 0;

      column_resizer.getLocation().then(function (navDivLocation) {
        column_resizer_x = navDivLocation.x;
        column_resizer_y = navDivLocation.y;

        // Жмём на середину ресайзера
        var x1 = column_resizer_x + column_resizer_width / 2;
        var x2 = column_resizer_y + column_resizer_height / 2;

        browser.actions().mouseMove({x: x1, y: x2}).doubleClick().perform();

        var new_column_resizer_x = 0;
        var new_column_resizer_y = 0;

        column_resizer.getLocation().then(function (new_navDivLocation) {
          new_column_resizer_x = new_navDivLocation.x;
          new_column_resizer_y = new_navDivLocation.y;

          // Положение ресайзера по оси у должно быть прежним
          expect(new_column_resizer_y).toEqual(column_resizer_y);
        });
      });
    });

    var new_current_column_height = 0;
    var new_current_column_width = 0;
    current_column.getSize().then(function (navDivSize) {
      new_current_column_height = navDivSize.height;
      new_current_column_width = navDivSize.width;

      // Высота колонки должна остаться прежней
      expect(new_current_column_height).toEqual(current_column_height);
    });

    // Если у колонки в теле есть элементы, то проверяем, что текст после двойного клика не скрывается (его размер <= нового размера колонки)
    if (current_column_body_first_elem.isPresent()) {
      var current_column_body_height = 0;
      var current_column_body_width = 0;

      current_column_body.each(function (elm) {
        current_column_body_height = 0;
        current_column_body_width = 0;
        return elm.getSize().then(function (navDivSize) {
          current_column_body_height = navDivSize.height;
          current_column_body_width = navDivSize.width;

          expect(current_column_body_height <= new_current_column_height).toBe(true);
          expect(current_column_body_width <= new_current_column_width).toBe(true);
        });
      });
    }
    else {
      expect(true).toBe(false);
    }

  });

});