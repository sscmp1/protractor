/**
 * @file       arrow-down.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Если изначально стрелки вниз => сортировка по убыванию
 *
 * @created    [03.08.2015] Lilia Sapurina.
 */

describe('Стрелка направлена вниз:', function () {

  var config = browser.params;
  var url = config.psGridUrl,
      grid,
      column;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.xpath(psGridXpath));
    grid.waitReady();

    column = grid.getColumnHead(2);
    column.click().click();
    grid.getColumnBody(2).get(0).toPsGrid().waitReady();
  });

  it('колонка отсортирована по убыванию', function () {

    // Стрелка направлена вниз, значит проверяем, что отсортировано по убыванию
    grid.getColumnBody(2).map(function (elm) {
      return elm.getText();
    }).then(function (values) {
      var sortedvalues = values.slice();
      sortedvalues = sortedvalues.sort(function (a, b) {
        if (a > b) {
          return 1;
        }
      });
      since('Колонка не отфильтрована по убыванию. Должно быть: #{expected}, на странице: #{actual}').
        expect(values).toEqual(sortedvalues);
    });

  });

});