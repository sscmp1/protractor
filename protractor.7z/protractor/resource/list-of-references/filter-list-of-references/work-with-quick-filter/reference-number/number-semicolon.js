/**
 * @file       number-semicolon.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при вводе значения с точкой с запятой, она преобразуется в запятую и колонка фильтруется по введённому номеру
 *
 * @created    [24.08.2015] Lilia Sapurina.
 */

describe('После ввода в поле "Номер" номера 16612;1 и нажатия ENTER', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      grid,
      numberField,
      column;

  beforeAll(function() {
    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Внутри компонента ps-Grid ищем быстрый фильтр поля "Номер" (1-я колонка)
    numberField = grid.getQuickFilter(gridFilter.number);
    // Кликнем на поле "Номер" и введём значение "16612;1"
    numberField.click().sendKeys("16612;1");
    // Нажмём ENTER
    numberField.pushKey("ENTER");

    // Внутри компонента ps-Grid ищем содержимое колонки "Номер" после ввода номера в фильтр (1-я колонка)
    column = grid.getColumn(gridFilter.number);
  });

  it('точка с запятой преобразуется в запятую', function () {
    since('Точка с запятой не преобразовалась в запятую').
         expect(numberField.getInputText()).toEqual("16612,1");
  });

  it('в списке одна запись', function () {
    since('В отфильтрованном списке запись не #{expected},их: #{actual}').
          expect(column.count()).toEqual(1);
  });

  it('список отфильтрован', function () {
    since('В отфильтрованном списке запись не равна #{expected}, а равна: #{actual}').
            expect(column.get(0).getText()).toEqual("16612,1");
  });

});