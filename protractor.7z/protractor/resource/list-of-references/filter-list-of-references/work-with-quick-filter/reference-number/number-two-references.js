/**
 * @file       number-two-references.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при наличии и точки с запятой и пробела, оба знака меняются на запятую и колонка сортируется по двум значениям
 *
 * @created    [24.08.2015] Lilia Sapurina.
 */

describe('После ввода в поле "Номер" номера 16612,1; 2 и обновления', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      grid,
      numberField,
      toolbar,
      column;

  beforeAll(function() {
    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Внутри компонента ps-Grid ищем быстрый фильтр поля "Номер" (1-я колонка)
    numberField = grid.getQuickFilter(gridFilter.number);
    // Кликнем на поле "Номер" и введём значение "16612;1 2"
    numberField.click().sendKeys("16612;1 2");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления и кликаем её
    toolbar.getRefreshButton().click();

    // Внутри компонента ps-Grid ищем содержимое колонки "Номер" после ввода номера в фильтр (1-я колонка)
    column = grid.getColumn(gridFilter.number);
  });

  it('точка с запятой и пробел преобразуются в запятые', function () {
    since('В отфильтрованном списке запись не равна #{expected}, а равна: #{actual}').
            expect(numberField.getInputText()).toEqual("16612,1,2");
  });

  it('в списке две записи', function () {
    since('В отфильтрованном списке записей не #{expected}, их: #{actual}').
            expect(column.count()).toEqual(2);
  });

  it('первая запись соответствует фильтрации', function () {
    since('В отфильтрованном списке первая запись не равна содержит ни одного значения из фильтра').
            expect(["16612","1","2"]).toContain(column.get(0).getText());
  });

  it('вторая запись соотвествует фильтрации', function () {
    since('В отфильтрованном списке вторая запись не равна содержит ни одного значения из фильтра').
            expect(["16612","1","2"]).toContain(column.get(1).getText());
  });

});