/**
 * @file       number-filter.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при вводе существующего номера обращения в поле быстрого фильтра фильтрация проводится верно
 *
 * @created    [24.08.2015] Lilia Sapurina.
 */

describe('После ввода номера зарегистрированного обращения и нажатия Enter', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      grid,
      existValue,
      numberField,
      column;

  beforeAll(function() {
    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на странице
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Внутри компонента ps-Grid ищем быстрый фильтр поля "Номер" (1-я колонка)
    numberField = grid.getQuickFilter(gridFilter.number);

    // Внутри компонента ps-Grid ищем содержимое колонки "Номер" (1-я колонка)
    column = grid.getColumn(gridFilter.number);

    // Вводим существующий номер
    existValue = column.get(0).getText().then(function(value){
      grid.getQuickFilter(gridFilter.number).click().sendKeys(value);
      return value;
    });

    // Нажмём ENTER
    numberField.pushKey("ENTER");
  });

  it('в списке один элемент', function () {
    since('В отфильтрованном списке запись не #{expected},их: #{actual}').
            expect(column.count()).toEqual(1);
  });

  it('список верно отфильтрован', function () {

    since('В отфильтрованной колонке номер не #{expected},a: #{actual}').
            expect(column.get(0).getText()).toEqual(existValue);
  });

});