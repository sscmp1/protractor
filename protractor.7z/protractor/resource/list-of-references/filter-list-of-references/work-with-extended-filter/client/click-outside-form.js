/**
 * @file       click-outside-form.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при клике вне формы список не появляется
 *
 * @created    [16.09.2015] Lilia Sapurina.
 */

describe('После клика вне формы', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      toolbar,
      tabs,
      client,
      indent,
      list,
      radioGroup;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();

    // Отступим на indent пикселей по обеим осям от элемента и кликнем мышью
    indent = Math.floor(Math.random()*20) + 80;
    browser.actions().mouseMove(radioGroup, {x: indent, y: indent}).click();
  });

  it('выбранный элемент: "Все клиенты"', function () {
    since('Выбранный элемент не "Все клиенты", а "#{actual}"').
            expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
  });
});

