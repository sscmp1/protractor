/**
 * @file       arrow-down.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при нажатии клавиши вниз появляется выпадающий список со всеми параметрами
 *
 * @created    [16.09.2015] Lilia Sapurina.
 */

describe('После нажатия на кнопку выпадающего списка', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      toolbar,
      tabs,
      client,
      list,
      radioGroup;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();
  });

  it('заголовок группы "Способ фильтрации" ', function () {
    since('Заголовок группы не "Способ фильтрации", а "#{actual}"').
            expect(list.getTopBarLabel().getText()).toEqual("Способ фильтрации");
  });

  it('расположение переключателей горизонтально ', function () {
    since('Переключатели не расположены горизонтально "#{actual}" "#{expected}"').
            expect(radioGroup.getCaptionWithText("Все клиенты").getX()).toBeLessThan(radioGroup.getCaptionWithText("Выбранный клиент").getX());
    since('Переключатели не расположены горизонтально "#{actual}" "#{expected}"').
            expect(radioGroup.getCaptionWithText("Выбранный клиент").getX()).toBeLessThan(radioGroup.getCaptionWithText("Выбранные абоненты").getX());
    since('Переключатели не расположены горизонтально "#{actual}" "#{expected}"').
            expect(radioGroup.getCaptionWithText("Выбранные абоненты").getX()).toBeLessThan(radioGroup.getCaptionWithText("Параметры клиента").getX());
  });

  it('присутствует элемент группы: "Все клиенты"', function () {
    since('Элемент группы "Все клиенты" не представлен, а "#{actual}"').
            expect(radioGroup.getCaptionWithText("Все клиенты").isPresent()).toBe(true);
  });

  it('присутствует элемент группы: "Выбранный клиент"', function () {
    since('Элемент группы "Выбранный клиент" не представлен, а "#{actual}"').
            expect(radioGroup.getCaptionWithText("Выбранный клиент").isPresent()).toBe(true);
  });

  it('присутствует элемент группы: "Выбранные абоненты"', function () {
    since('Элемент группы "Выбранные абоненты" не представлен, а "#{actual}"').
            expect(radioGroup.getCaptionWithText("Выбранные абоненты").isPresent()).toBe(true);
  });

  it('присутствует элемент группы: "Параметры клиента"', function () {
    since('Элемент группы "Параметры клиента" не представлен, а "#{actual}"').
            expect(radioGroup.getCaptionWithText("Параметры клиента").isPresent()).toBe(true);
  });

  it('выбранный элемент: "Все клиенты"', function () {
    since('Выбранный элемент не "Все клиенты", а "#{actual}"').
            expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
  });
});
