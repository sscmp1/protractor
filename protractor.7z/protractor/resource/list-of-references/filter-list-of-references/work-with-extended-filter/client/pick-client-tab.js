/**
 * @file       pick-client-tab.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при клике на вкладку "Клиент" вкладка выбирается верно
 *
 * @created    [16.09.2015] Lilia Sapurina.
 */

describe('После нажатия на вкладку "Клиент"', function () {

  var config = browser.params;
  var url = config.listOfReferencesUrl,
      toolbar,
      tabs,
      client,
      contacts,
      treatment;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    // Обратимся к соседним вкладкам - "Контакты" и "Обработка", чтобы понять, что соседние вкладки визуально отличаются
    contacts = tabs.getTabByName("Контакты");
    treatment = tabs.getTabByName("Обработка");

  });

  it('она выделена', function () {

    // Извлечём цвет вкладки в формате rgba(.,.,.,.)
    client.getCssValue('color').then(function (color1) {

      // Сравним цвета вкладок "Контакты" и "Клиент"
      contacts.getCssValue('color').then(function (color2) {
        since('Вкладка не отличается от вкладки "Контакты"').
            expect(color1).not.toEqual(color2);
      });

      // Сравним цвета вкладок "Клиент" и "Обработка"
      treatment.getCssValue('color').then(function (color2) {
        since('Вкладка не отличается от вкладки "Обработка"').
                expect(color1).not.toEqual(color2);
      });

    });
  });

});

