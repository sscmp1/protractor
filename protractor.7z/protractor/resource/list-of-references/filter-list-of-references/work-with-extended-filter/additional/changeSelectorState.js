/**
 * Created by Evgeniia.Bessarab on 19.10.2015.
 */

describe('Смена состояния переключателя', function () {

  var lib = require("../common.js"),
      config = browser.params,
      url = config.listOfReferencesUrl,
      toolbar,
      tabs,
      additionalTabName = "Дополнительно",
      repeatInqRadioGroup,
      repeatPeriod = function () {
      },
      firstEnter = {
        startTime: "",
        stateFieldTime: "",
        radioButtonNameWithBall: ""
      };

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");
    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css("ps-toolbar[class='n-panel no-select']"));
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();
    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath("//ul[@class='n-tabs']"));
    // Кликнем на вкладку "Дополнительно"
    tabs.getTabByName(additionalTabName).click();
    repeatPeriod = psDuration(by.xpath("//div[contains(@class,'ps-duration')]"));
    repeatInqRadioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
  });


  it('Изменить состояние переключателя.', function () {
    repeatInqRadioGroup.getRadioButtonWithGreenBall().getText().then(function (text) {
      firstEnter.startTime = repeatPeriod.getState();
      firstEnter.stateFieldTime = repeatPeriod.getTextValue();
      if (text == 'Нет') {
        firstEnter.radioButtonNameWithBall = 'Нет';
        since('Неправильное состояние у поля "Период повторения" до клика Да. Не #{expected},а: #{actual}').
            expect(repeatPeriod.getState()).toEqual('disable');
        repeatInqRadioGroup.clickOnCaption("Да");
        since('Неправильное состояние у поля "Период повторения" после клика Да. Не #{expected},а: #{actual}').
            expect(repeatPeriod.getState()).toEqual('enable');
      } else {
        firstEnter.radioButtonNameWithBall = 'Да';
        since('Неправильное состояние у поля "Период повторения" до клика Нет. Не #{expected},а: #{actual}').
            expect(repeatPeriod.getState()).toEqual('enable');
        repeatInqRadioGroup.clickOnCaption("Нет");
        since('Неправильное состояние у поля "Период повторения" после клика Нет. Не #{expected},а: #{actual}').
            expect(repeatPeriod.getState()).toEqual('disable');
      }
    });
  });


  it('Изменить состояние переключателя еще 4 раза.', function () {
    var startTime = repeatPeriod.getTextValue();
    for (var i = 0; i < 4; i++) {
      repeatInqRadioGroup.getRadioButtonWithGreenBall().getText().then(function (text) {  // NOSONAR
        firstEnter.startTime = repeatPeriod.getState();
        firstEnter.stateFieldTime = repeatPeriod.getTextValue();
        if (text == 'Нет') {
          since('Неправильное состояние у поля "Период повторения" до клика Да. Не #{expected},а: #{actual}').
              expect(repeatPeriod.getState()).toEqual('disable');
          repeatInqRadioGroup.clickOnCaption("Да");
          since('Неправильное состояние у поля "Период повторения" после клика Да. Не #{expected},а: #{actual}').
              expect(repeatPeriod.getState()).toEqual('enable');
        } else {
          since('Неправильное состояние у поля "Период повторения" до клика Нет. Не #{expected},а: #{actual}').
              expect(repeatPeriod.getState()).toEqual('enable');
          repeatInqRadioGroup.clickOnCaption("Нет");
          since('Неправильное состояние у поля "Период повторения" после клика Нет. Не #{expected},а: #{actual}').
              expect(repeatPeriod.getState()).toEqual('disable');
        }
      });
    }
    since('Изменилось значение в поле со временем. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getTextValue()).toEqual(startTime);


  });

  it('Нажать "Отменить"', function () {
    lib.getCancelButton().click();
    // Проверяем,что перешли на список обращений
    var result = element(by.xpath("//div[@load-form='inquiryListFilter'][contains(@class,'ng-hide')]")) &&
    element(by.xpath("//ps-splitter[@ng-hide='formData.state.showFilter'][not(contains(@class,'ng-hide'))]")) ? true : false;
    since('Мы не перешли на список обращений. Не #{expected},а: #{actual}').
        expect(result).toEqual(true);
  });

  it('Снова открыть форму фильтра, закладку "Дополнительно".', function () {
    toolbar.getSearchButton().click();
    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath("//ul[@class='n-tabs']"));
    // Кликнем на вкладку "Дополнительно"
    tabs.getTabByName(additionalTabName).click();

    since('Состояние переключателя периода повторения не соответствует состоянию на момент начала выполнения теста. Не #{expected},а: #{actual}').
        expect(repeatInqRadioGroup.getRadioButtonWithGreenBall().getText()).toEqual(firstEnter.radioButtonNameWithBall);
    since('Состояние поля времени не соответствует состоянию на момент начала выполнения теста. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getState()).toEqual(firstEnter.startTime);
    since('Значение времени периода повторения не соответствует состоянию на момент начала выполнения теста. Не #{expected},а: #{actual}').
        expect(repeatPeriod.getTextValue()).toEqual(firstEnter.stateFieldTime);

  });

  it('Изменить состояние переключателя после повторного открытия формы.', function () {
    repeatInqRadioGroup.getRadioButtonWithGreenBall().getText().then(function (text) {
      if (text == 'Нет') {
        console.log('No');
        since('Неправильное состояние у поля "Период повторения" до клика Да. Не #{expected},а: #{actual}').
            expect(repeatPeriod.getState()).toEqual('disable');
        repeatInqRadioGroup.clickOnCaption("Да");
        since('Неправильное состояние у поля "Период повторения" после клика Да. Не #{expected},а: #{actual}').
            expect(repeatPeriod.getState()).toEqual('enable');
      } else {
        console.log('Yes');
        since('Неправильное состояние у поля "Период повторения" до клика Нет. Не #{expected},а: #{actual}').
            expect(repeatPeriod.getState()).toEqual('enable');
        repeatInqRadioGroup.clickOnCaption("Нет");
        since('Неправильное состояние у поля "Период повторения" после клика Нет. Не #{expected},а: #{actual}').
            expect(repeatPeriod.getState()).toEqual('disable');
      }
    });
  });

});

