/**
 * @file       ps-grid-column-filter-range_negative_interval.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Ввод отрицательного диапазона (например -1.01 - -0.99): возможность ввода и корректное отображение.
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_negative_interval', function () {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var balloon_warning_css = config.balloon_warning_css;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));
  var balloon_warning = $(balloon_warning_css);

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('корректная работа с отрицательными интервалами', function () {

    filter_field.click();
    browser.actions().click(filter_field).perform();

    // Введём отрицательный интервал
    filter_field.sendKeys('-1.01 - -0.99');

    browser.wait(function () {
      return balloon_warning.isPresent();
    }, 3000).then(function () {
      expect(balloon_warning.isDisplayed()).toBe(false);
    }).thenCatch(function () {
      expect(balloon_warning.isPresent()).toBe(false);
    });

    expect(filter_field.getAttribute("value")).toEqual('-1.01 – -0.99');

  });

});