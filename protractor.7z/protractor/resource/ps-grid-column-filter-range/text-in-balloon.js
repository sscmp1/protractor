/**
 * @file       ps-grid-column-filter-range_text_in_balloon.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview balloon содержит следующие данные: текст "Допустимо вводить диапазон от"; текст "Например:"
 *
 * @created    [31.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_text_in_balloon', function () {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var balloon_info_css = config.balloon_info_css;
  var balloon_info_text_css = config.balloon_info_text_css;
  var balloon_contain_text = config.balloon_contain_text;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));
  var balloon_info = $(balloon_info_css);
  var balloon_text = balloon_info.element(by.css(balloon_info_text_css));

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('балун содержит текст', function () {
    filter_field.click();
    browser.actions().click(filter_field).perform();

    browser.wait(function() {
      var deferred = protractor.promise.defer();
      balloon_info.isPresent().then(function (isPresent) {
        expect(balloon_text.getText()).toContain(balloon_contain_text);
        expect(balloon_text.isDisplayed()).toBe(true);
        deferred.fulfill(isPresent);
      },function () {
        deferred.fulfill(!isPresent);
      });
      return deferred.promise;
    });

  });

});