/**
 * @file       ps-grid-column-filter-range_correct_value.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Возможность ввода в поле (и корректное отображение) значений correct_value
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_correct_value', function () {

  var config = browser.params;

  // Глобальные параметры
  var correct_value = config.correct_value;
  var filter_field_xpath = config.filter_field_xpath;
  var balloon_warning_css = config.balloon_warning_css;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));
  var balloon_warning = $(balloon_warning_css);

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('должна быть возможность вводить корректные значения', function () {

    filter_field.click();
    browser.actions().click(filter_field).perform();
    filter_field.sendKeys(correct_value);

    var EC = protractor.ExpectedConditions;
    browser.wait(EC.presenceOf(balloon_warning), 3000).then(function () {
      expect(balloon_warning.isDisplayed()).toBe(false);
    }, function () {
      expect(balloon_warning.isPresent()).toBe(false);
    });

    expect(filter_field.getAttribute("value")).toEqual(correct_value);

  });

});