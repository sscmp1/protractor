/**
 * @file       ps-grid-column-filter-range_correct_filter.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Ввод существующего значения: корректная фильтрация по нажатию ENTER/TAB/клику вне поля
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_correct_filter', function() {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var columns_xpath = config.columns_xpath;
  var column_body_xpath = config.column_body_xpath;
  var key_value = config.key_value;
  var column_number = config.column_number;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));
  var all_columns = element.all(by.xpath(columns_xpath));
  var column_body = element.all(by.xpath(column_body_xpath));

  var current_column = all_columns.get(column_number - 1);

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('фильтрация по значению должна быть корректной',function(){

     filter_field.click();
     // Извлечём существующее (елси оно существует) в списке значение, например из 1-й строки
     if(column_body.get(0).isPresent()){

       var exist_value = column_body.get(0).getText();
       filter_field.sendKeys(exist_value);

       // Подтверждаем ввод клавишей ENTER
       if(key_value == 'ENTER') {
         browser.actions().sendKeys(protractor.Key.ENTER).perform();
       }
       // Подтверждаем ввод клавишей TAB
       if(key_value == 'TAB') {
         browser.actions().sendKeys(protractor.Key.TAB).perform();
       }
       // Подтверждаем ввод кликом вне компонента
       if(key_value == 'MOUSE') {
             // Вычислим высоту компонента
             var current_column_height = 0;
             current_column.getSize().then(function (navDivSize) {
                                                       current_column_height = navDivSize.height;
                                            });

             // Вычислим координаты компонента
             var current_column_x = 0;
             var current_column_y = 0;
             current_column.getLocation().then(function (navDivLocation) {
                                                       current_column_x = navDivLocation.x;
                                                       current_column_y = navDivLocation.y;
                                               });

             // Кликнем мышкой вне компонента (немного ниже)
             browser.actions().click({x:current_column_x, y: current_column_y + current_column_height + 20}).perform();
       }

       var filtered_values = element.all(by.xpath(column_body_xpath));

        // Проверяем, что вся колонка равна изначально выбранному значению
        filtered_values.each(function(element) {
           expect(element.getText()).toEqual(exist_value);
        });
     }
     else {
        // Тело пусто, проверка невозможна
        expect(true).toBe(false);
     }

  });

});
