/**
 * @file       ps-grid-column-filter-range_filter_one_side_interval.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка ввода только одной границы диапазона (например, >[первое значение в списке]): возможность ввода, корректное отображение, корректная фильтрация (для обоих случаев: < и >)
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_filter_one_side_interval', function () {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var column_body_xpath = config.column_body_xpath;

  // Локальные переменные
  var filter_field = element(by.xpath(filter_field_xpath));
  var column_body = element.all(by.xpath(column_body_xpath));

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });


  it('корректная фильтрация по одностороннему интервалу >', function () {

    filter_field.click();
    if (column_body.get(0).isPresent()) {

      var exist_value = column_body.get(0).getText().then(function (value) {
        var floatValue = parseFloat(value);
        return (floatValue);
      });
      filter_field.sendKeys(">");
      filter_field.sendKeys(exist_value);
      var filtered_values = column_body;

      // Проверяем, что вся пятая отфильтрованная колонка больше либо равна изначально выбранному значению
      filtered_values.each(function (element) {
        var current_value = element.getText().then(function (value) {
          var floatValue = parseFloat(value);
          return (floatValue);
        });
        expect(exist_value).toBeLessThan(current_value);
      });
    }
    else {
      expect(true).toBe(false);
    }

    filter_field.clear();
    console.log("ps-grid-column-filter-range_spec_9");
  });

  it('корректная фильтрация по одностороннему интервалу <', function () {

    filter_field.click();
    if (column_body.get(0).isPresent()) {

      var exist_value = column_body.get(0).getText().then(function (value) {
        var floatValue = parseFloat(value);
        return (floatValue);
      });
      filter_field.sendKeys("<");
      filter_field.sendKeys(exist_value);
      var filtered_values = column_body;

      // Проверяем, что вся пятая отфильтрованная колонка меньше либо равна изначально выбранному значению
      filtered_values.each(function (element) {
        var current_value = element.getText().then(function (value) {
          var floatValue = parseFloat(value);
          return (floatValue);
        });
        expect(exist_value).toBeGreaterThan(current_value);
      });
    }
    else {
      expect(true).toBe(false);
    }

  });

});
