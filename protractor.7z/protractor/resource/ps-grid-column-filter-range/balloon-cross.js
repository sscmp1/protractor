/**
 * @file       ps-grid-column-filter-range_balloon_cross.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview При клике по крестику в балуне он скрывается
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */

describe('ps-grid-column-filter-range_balloon_cross', function () {

  var config = browser.params;

  // Глобальные переменные
  var filter_field_xpath = config.filter_field_xpath;
  var balloon_info_css = config.balloon_info_css;
  var balloon_cross_css = config.balloon_cross_css;

  // Поиск по локатору
  var filter_field = element(by.xpath(filter_field_xpath));
  var balloon_info = $(balloon_info_css);
  var balloon_cross = balloon_info.element(by.css(balloon_cross_css));

  beforeEach(function(){
    browser.get('ng-components/examples/ps-grid-column-filter-range.html');
  });

  it('балун должен быть закрыт после нажатия на крестик', function () {
    filter_field.click();
    browser.actions().click(filter_field).perform();

    // Блокирующий wait (при стандартном wait при массовом запуске тесты не срабатывают)
    browser.wait(function() {
      var deferred = protractor.promise.defer();
      balloon_info.isPresent().then(function (isPresent) {
        balloon_cross.click();
        expect(balloon_info.isDisplayed()).toBe(false);
        deferred.fulfill(isPresent);
      },function () {
        deferred.fulfill(!isPresent);
      });
      return deferred.promise;
    });

  });

});
