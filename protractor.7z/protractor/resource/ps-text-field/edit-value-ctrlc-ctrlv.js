/**
 * @file       edit-value-ctrlc-ctrlv.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка корректности нажатия клавиш CTRL+A, CTRL+V, CTRL+C
 *
 * @created    [04.09.2015] Lilia Sapurina.
 */

describe('После выделения содержимого поля и нажатия комбинаций CTRL + C и CTRL+V в другом поле', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field1,
          field2;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Вводим произвольное сообщение и удаляем последний символ
    field1 = textField.getTextField(1);
    field1.clear();
    field1.click().sendKeys("Hello");
    // Выделили текст
    field1.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "a"));
    // Скопировали текст
    field1.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "c"));

    // Перешли к следующему полю
    field2 = textField.getTextField(2);
    // Кликнули на него и очистили
    field2.clear().click();
    // Вставили значение из буфера
    field2.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "v"));
  });

  it('содержимое поля становится равным скопированному', function () {
    since('Вставленное значение не #{expected},а: #{actual}').
            expect(field2.getInputText()).toEqual("Hello");
  });

});

