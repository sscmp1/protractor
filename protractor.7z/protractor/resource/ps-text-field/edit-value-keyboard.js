/**
 * @file       edit-value-keyboard.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка возможности редактирования значения при помощи клавиатуры
 *
 * @created    [04.09.2015] Lilia Sapurina.
 */

describe('После нажатия в текстовое поле и ввода символов', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Устанавливаем своё значение по умолчанию для тестового поля
    field = textField.getTextField(2);
    field.clear();
    field.click().sendKeys("Hello!");
  });

  it('значение в поле верно обновляется', function () {
    since('Обновлённое значение не #{expected},а: #{actual}').
            expect(field.getInputText()).toEqual("Hello!");
  });

});

