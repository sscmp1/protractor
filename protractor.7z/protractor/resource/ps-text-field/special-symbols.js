/**
 * @file       special-symbols.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка возможности ввода специальных символов (" ' ` | / \ , ; : & < > ^ * ? Tab « »)
 *
 * @created    [04.09.2015] Lilia Sapurina.
 */

describe('После ввода специального символа:', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
  });

  describe('"', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys('"');
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual('"');
    });
  });

  describe('/', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("/");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual("/");
    });
  });

  describe('\\', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("\\");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual("\\");
    });
  });

  describe('|', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("|");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("|");
    });
  });

  describe('\'', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("\'");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("\'");
    });
  });

  describe(',', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys(",");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual(",");
    });
  });

  describe(';', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys(";");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual(";");
    });
  });

  describe(':', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys(":");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual(":");
    });
  });

  describe('&', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("&");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("&");
    });
  });

  describe('>', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys(">");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual(">");
    });
  });

  describe('<', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("<");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("<");
    });
  });

  describe('«', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("«");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("«");
    });
  });

  describe('»', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("»");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("»");
    });
  });

  describe('Tab', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("Tab");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("Tab");
    });
  });

  describe('?', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("?");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("?");
    });
  });

  describe('`', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("`");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("`");
    });
  });

  describe('*', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("*");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("*");
    });
  });

  describe('^', function () {
    it('строка отображается корректно', function () {
      field.clear().click().sendKeys("^");
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(textField.getTextField(1).getInputText()).toEqual("^");
    });
  });

});
