/**
 * @file       ie-copy.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что использование контекстного меню IE работают: пункт "Копировать"
 *
 * @created    [30.10.2015] Lilia Sapurina.
 */

describe('После выделения текста и выбора пункта "Копировать" в контекстном меню', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field1,
          field2;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Вводим произвольное сообщение и удаляем последний символ
    field1 = textField.getTextField(1);
    field1.clear();
    field1.click().sendKeys("Hello!");
    field1.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "a"));
    field1.rightClick();
    browser.actions().sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.ENTER).perform();

    // Втавим это значение в следующее поле
    field2 = textField.getTextField(2);
    field2.clear().click();
    field2.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "v"));
  });

  it('копирование произведено верно', function () {
    since('Копированное значение не #{expected},а: #{actual}').
            expect(field2.getInputText()).toEqual("Hello!");
  });

});

