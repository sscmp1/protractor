/**
 * @file       create-default-value.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка заполнения значения по умолчанию в текстовом поле
 *
 * @created    [04.09.2015] Lilia Sapurina.
 */

describe('После установления значения по умолчанию в поле "Норма"', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Устанавливаем своё значение по умолчанию для тестового поля
    field = textField.getDefaultField(1);
    field.click().sendKeys("my default value");

  });

  it('в поле устанавливается верное значение по умолчанию', function () {
    since('Установленное значение не #{expected},а: #{actual}').
            expect(field.getInputText()).toEqual("my default value");
  });

});