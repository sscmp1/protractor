/**
 * @file       long-string.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка ввода строк длины 255 символов
 *
 * @created    [05.09.2015] Lilia Sapurina.
 */

describe('После строки в', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field,
          long_string;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
  });

  describe('255 символов', function () {

    long_string = create_string_by_length(255,'p');

    it('она отображается корректно', function () {
      field.clear().click().sendKeys(long_string);
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual(long_string);
    });
  });

  describe('256 символов', function () {

    long_string = create_string_by_length(256,'p');

    it('она отображается корректно', function () {
      field.clear().click().sendKeys(long_string);
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual(long_string);
    });
  });

  describe('257 символов', function () {

    long_string = create_string_by_length(257,'p');

    it('она отображается корректно', function () {
      field.clear().click().sendKeys(long_string);
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual(long_string);
    });
  });

  describe('1000 символов', function () {

    long_string = create_string_by_length(1000,'p');

    it('она отображается корректно', function () {
      field.clear().click().sendKeys(long_string);
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual(long_string);
    });
  });

  describe('1024 символов', function () {

    long_string = create_string_by_length(1024,'p');

    it('она отображается корректно', function () {
      field.clear().click().sendKeys(long_string);
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual(long_string);
    });
  });

  describe('2000 символов', function () {

    long_string = create_string_by_length(2000,'p');

    it('она отображается корректно', function () {
      field.clear().click().sendKeys(long_string);
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual(long_string);
    });
  });

  describe('2048 символов', function () {

    long_string = create_string_by_length(2048,'p');

    it('она отображается корректно', function () {
      field.clear().click().sendKeys(long_string);
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual(long_string);
    });
  });

});

