/**
 * @file       tab.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что при нажатии клавиши TAB происходит переход на следующее поле ввода
 *
 * @created    [10.09.2015] Lilia Sapurina.
 */

describe('После нажатия клавиши TAB', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field1,
          field2,
          highlightedText;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field1 = textField.getTextField(2);
    // Ввели какое-то конкретное значение в первое поле
    field1.clear().sendKeys("Hello1");
    field2 = textField.getTextField(3);
    // Ввели какое-то конкретное значение во второе поле
    field2.clear().sendKeys("Hello2");
    field1.click();
    // Нажали TAB
    browser.actions().sendKeys(protractor.Key.TAB).perform();
    // Дважды кликнув мышкой выделили текст
    browser.actions().click().click();
    // Извлекли выделенный текст
    highlightedText = field2.getHighlightedText();
  });

  it('курсор переводится на следующее поле', function () {
    since('Курсор остался там же, где и был').
            expect(highlightedText).toEqual('Hello2');
  });

});
