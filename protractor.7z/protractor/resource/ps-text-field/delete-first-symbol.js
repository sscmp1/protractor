/**
 * @file       delete-first-symbol.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка корректного удаление первого символа
 *
 * @created    [30.10.2015] Lilia Sapurina.
 */

describe('После удаление первого символа', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Вводим произвольное сообщение и удаляем последний символ
    field = textField.getTextField(1);
    field.clear();
    field.click().sendKeys("Hello");

    browser.actions().sendKeys(protractor.Key.LEFT).sendKeys(protractor.Key.LEFT).sendKeys(protractor.Key.LEFT).sendKeys(protractor.Key.LEFT).sendKeys(protractor.Key.BACK_SPACE).perform();
  });

  it('строка отображается корректно', function () {
    since('Удаление произведено неверно, в поле не #{expected},а: #{actual}').
            expect(field.getInputText()).toEqual("ello");
  });

});

