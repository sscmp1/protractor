/**
 * @file       string-with-accents.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка возможности вводить строки с символами ударения
 *
 * @created    [04.09.2015] Lilia Sapurina.
 */

describe('После ввода строки àáâãäåçèéêëìíîðñòôõöö', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Вводим строку с символами ударения
    field = textField.getTextField(1);
    field.clear().click().sendKeys("àáâãäåçèéêëìíîðñòôõöö");
  });

  it('она отображается корректно', function () {
    since('Обновлённое значение не #{expected},а: #{actual}').
            expect(field.getInputText()).toEqual("àáâãäåçèéêëìíîðñòôõöö");
  });

});