/**
 * @file       ukraine-symbols.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка возможности ввода украинских символов: ₴ Ґ/ґ ієї
 *
 * @created    [30.10.2015] Lilia Sapurina.
 */

describe('После ввода украинских символов: ₴ Ґ/ґ ієї ', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
  });

  it('строка отображается корректно', function () {
    field.clear().click().sendKeys('₴ Ґ/ґ ієї');
    since('Обновлённое значение не #{expected},а: #{actual}').
            expect(field.getInputText()).toEqual('₴ Ґ/ґ ієї');
  });

});
