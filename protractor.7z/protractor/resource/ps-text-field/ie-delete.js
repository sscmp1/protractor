/**
 * @file       ie-delete.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка, что использование контекстного меню IE работает: пункт "Удалить"
 *
 * @created    [10.09.2015] Lilia Sapurina.
 */

describe('После нажатия пункта "Удалить" в контекстном меню IE', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
    field.clear().sendKeys("Hello");
    browser.actions()
            .click(field)
            .sendKeys(protractor.Key.LEFT)
            .click(protractor.Button.RIGHT)
            .perform();

    browser.actions().sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.DOWN)
            .sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.ENTER).perform();
    browser.sleep(3000);
  });

  it('текст удаляется', function () {
    since('Значение не пусто,а равно: #{actual}').
            expect(field.getInputText()).toEqual('Hell');
  });

});

