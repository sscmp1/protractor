/**
 * @file       bad-enough-string.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка возможности ввода "достаточно плохой" строки
 *
 * @created    [04.09.2015] Lilia Sapurina.
 */

describe('После ввода специальной строки: "[|]\'~<!--@/*$%^&#*/()?>,.*/© ', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
    field.clear().click().sendKeys('"[|]\'~<!--@/*$%^&#*/()?>,.*/©');
  });

    it('строка отображается корректно', function () {
      since('Обновлённое значение не #{expected},а: #{actual}').
              expect(field.getInputText()).toEqual('"[|]\'~<!--@/*$%^&#*/()?>,.*/©');
    });

});

