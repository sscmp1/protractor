/**
 * @file       right-key.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Проверка возможности использования кнопки "вправо"
 *
 * @created    [10.09.2015] Lilia Sapurina.
 */

describe('После нажатия правой стрелки', function () {

  var config = browser.params;
  var url = config.psTextFieldUrl,
          textField,
          field,
          oldX,
          newX;

  beforeAll(function () {
    browser.get(url);
    browser.waitForAngular();

    textField = psTextField(by.css(psTextFieldCss));
    textField.waitReady();

    // Обратимся к нужной строке
    field = textField.getTextField(1);
    field.clear().click().sendKeys('Hello!');
    // Извлекли положение курсора в строке
    oldX = field.getCaretPosition();

    // Сдвинули курсор на одну позицию влево
    field.pushKey("LEFT");
    field.pushKey("LEFT");
    field.pushKey("RIGHT");
    // Извлекли новое положение курсора + 1
    newX = field.getCaretPosition().then(function (value) {
      return value + 1;
    });
  });

  it('курсор перемещается на позицию влево', function () {
    since('Обновлённое значение не #{expected},а: #{actual}').
            expect(oldX).toEqual(newX);
  });

});
