/**
 * @file       list-of-references_spec.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia.Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview
 *
 * @created    [28.07.2015] Lilia.Sapurina.
 */


describe('Test_filters', function() {

  var config = browser.params;

  var req = config.req_lib_filter;
  require(req);

  var tester_column_number = config.column_number_filter;
  var tester_url = config.url_filter;

  var filter_field = element(by.xpath("//td[@class='ng-scope n-grid__filter']["+ tester_column_number +"]"));
  var value_not_from_list = 56;
  var balloon_info = $('div[class="n-balloon n-balloon_bottom_left n-balloon_can_close n-balloon_info"]');
  var balloon_warning = $('div[class="n-balloon n-balloon_bottom_left n-balloon_can_close n-balloon_has_icon n-balloon_warning"]');

beforeEach(function() {
    browser.get(tester_url);
});


it('balloon should contain text',function(){
    filter_field.click();
    browser.sleep(3000);
    var balloon_text = (balloon_info.element(by.css('div'))).element(by.css('span'));
    var height = balloon_info.getAttribute("style");
    expect(height).toContain("height: 50px;");
    expect(balloon_text.getText()).toContain('Допустимо вводить диапазон от');
    expect(balloon_text.getText()).toContain('Например:');
    console.log("Test 1.1 done!");
});

it('should show balloon',function(){
    filter_field.click();
    browser.sleep(3000);
    if (balloon_info.isPresent()) {
      expect(balloon_info.isDisplayed()).toBe(true);
    }
    else {
      expect(true).toBe(false);
    }
    console.log("Test 1.1 done!");
});

it('should show balloon near field',function(){
    filter_field.click();
    browser.sleep(3000);

    if (balloon_info.isPresent()){

        var filter_field_x = 0;
        var filter_field_y = 0;

        filter_field.getLocation().then(function (navDivLocation) {
            filter_field_x = navDivLocation.x;
            filter_field_y =  navDivLocation.y;

            balloon_info.getLocation().then(function (navDivLocation2) {
                var balloon_x = navDivLocation2.x;
                var balloon_y = navDivLocation2.y;

                expect(balloon_x-filter_field_x).toBeLessThan(10) && (balloon_y-filter_field_y).toBeLessThan(40);
            });
        });
    } else {
       expect(true).toBe(false);
      }

    console.log("Test 1.1 done!");
});

  it('should be closen',function(){
     filter_field.click();
     browser.sleep(3000);
     var balloon_cross = balloon_info.element(by.css('span[class=n-balloon__close]'));
     balloon_cross.click();
     browser.sleep(3000);
     if (balloon_info.isPresent()) {
       expect(balloon_info.isDisplayed()).toBe(false);
     }
     else {
       expect(true).toBe(false);
     }
     console.log("Test 1.2 done!");
  });

it('value should be valid',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    filter_field_text.sendKeys('9999999999999');
    browser.sleep(3000);
    if (balloon_warning.isPresent()) {
      expect(balloon_warning.isDisplayed()).toBe(true);
    }
    else {
      expect(true).toBe(false);
    }
    console.log("Test 3 done!");
});

it('should can put valid value',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    filter_field_text.sendKeys('-999999999999.00');
    browser.sleep(3000);
    expect(balloon_warning.isPresent()).toBe(false);
    expect(filter_field_text.getAttribute("value")).toEqual('-999999999999.00');
    console.log("Test 2.1 done!");
});

it('no data should be shown',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    filter_field_text.sendKeys(value_not_from_list);
    browser.sleep(3000);
    var no_data_field = element(by.xpath("//div[@class='n-grid-nothing-found']/span[2]"));
    if (no_data_field.isPresent()) {
      expect(no_data_field.getText()).toEqual('Нет данных');
    }
    else {
      expect(true).toBe(false);
    }
    console.log("Test 2.2 done!");
});

it('should filtering correctly',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    var exist_value = element(by.xpath('//tr[@data-row-index="1"]/td[@data-column-index="5"]/div')).getText();
    filter_field_text.sendKeys(exist_value);
    browser.sleep(3000);
    var filtered_values = element.all(by.xpath('//tr/td[@data-column-index="5"]/div'));
    filtered_values.each(function(element) {
        expect(element.getText()).toEqual(exist_value);
    });
    console.log("Test 4 done!");
});

it('should clean field correctly',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    filter_field_text.sendKeys('-999999999999.00');
    browser.sleep(3000);
    filter_field_text.clear();
    browser.sleep(3000);
    expect(filter_field_text.getAttribute("value")).toEqual('');
    console.log("Test 5 done!");
});

it('should make corrections for wrong intervals',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    filter_field_text.sendKeys('2-1');
    browser.sleep(3000);
    filter_field.click();
    expect(filter_field_text.getAttribute("value")).toEqual('2 – 10');
    console.log("Test 6.1 done!");
});

it('should show balloon is interval is absolutely wrong',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    filter_field_text.sendKeys('1.01 - 0');
    browser.sleep(3000);
    if (balloon_warning.isPresent()) {
      expect(balloon_warning.isDisplayed()).toBe(true);
    }
    else {
      expect(true).toBe(false);
    }
    console.log("Test 6.2 done!");
});

it('should good working with negative values',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    filter_field_text.sendKeys('-1.01 - -0.99');
    browser.sleep(3000);
    if (balloon_warning.isPresent()) {
      expect(balloon_warning.isDisplayed()).toBe(false);
    }
    else {
      expect(true).toBe(false);
    }
    expect(filter_field_text.getAttribute("value")).toEqual('-1.01 – -0.99');
    console.log("Test 7 done!");
});

it('should filtering by interval correctly',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));

    var exist_value1 = element(by.xpath('//tr[@data-row-index="1"]/td[@data-column-index="5"]/div')).getText().then (function(value){
                                                                                                                      var floatValue =parseFloat(value);
                                                                                                                      return (floatValue); });
    var exist_value2 = element(by.xpath('//tr[@data-row-index="1"]/td[@data-column-index="5"]/div')).getText().then (function(value){
                                                                                                                      var floatValue = parseFloat(value);
                                                                                                                      return Math.round(floatValue)+1; });
    filter_field_text.sendKeys(exist_value1);
    filter_field_text.sendKeys('-');
    filter_field_text.sendKeys(exist_value2);
    var filtered_values = element.all(by.xpath('//tr/td[@data-column-index="5"]/div'));
    filtered_values.each(function(element) {
        var current_value = element.getText().then (function(value){
                                   var floatValue =parseFloat(value);
                                   return (floatValue); });
        expect((exist_value1<=current_value) || (exist_value2>=current_value)).toBeTruthy();
    });
    console.log("Test 8 done!");
});

it('should filtering by one-sided > interval correctly',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    var exist_value = element(by.xpath('//tr[@data-row-index="1"]/td[@data-column-index="5"]/div')).getText().then (function(value){
                                                                                                                      var floatValue =parseFloat(value);
                                                                                                                      return (floatValue); });
    filter_field_text.sendKeys(">");
    filter_field_text.sendKeys(exist_value);
    var filtered_values = element.all(by.xpath('//tr/td[@data-column-index="5"]/div'));
    filtered_values.each(function(element) {
        var current_value = element.getText().then (function(value){
                                   var floatValue =parseFloat(value);
                                   return (floatValue); });
        expect(exist_value).toBeLessThan(current_value);
    });
    console.log("Test 9 '>' done!");
});

it('should filtering by one-sided < interval correctly',function(){
    filter_field.click();
    var filter_field_text = filter_field.element(by.css('input'));
    var exist_value = element(by.xpath('//tr[@data-row-index="1"]/td[@data-column-index="5"]/div')).getText().then (function(value){
                                                                                                                      var floatValue =parseFloat(value);
                                                                                                                      return (floatValue); });
    filter_field_text.sendKeys("<");
    filter_field_text.sendKeys(exist_value);
    browser.sleep(5000);
    var filtered_values = element.all(by.xpath('//tr/td[@data-column-index="5"]/div'));
    filtered_values.each(function(element) {
        var current_value = element.getText().then (function(value){
                                   var floatValue =parseFloat(value);
                                   return (floatValue); });
        expect(exist_value).toBeGreaterThan(current_value);
    });
    console.log("Test 9 '<' done!");
});

});
