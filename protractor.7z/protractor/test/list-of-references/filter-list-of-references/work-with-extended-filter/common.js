/**
 * @file       common.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Общие пользовательские методы в форме расширенного фильтра
 *
 * @created    [30.10.2015] Lilia Sapurina.
 */

// Кнопка "Применить"
this.getApplyButton = function() {
  return element(by.xpath("//a[@class='b-button']/span[contains(@class,'b-button__label')][contains(text(),'Применить')]"));
};

// Кнопка "Очистить"
this.getClearButton = function() {
  return element(by.xpath("//a[@class='b-button']/span[@class='b-button__label'][contains(text(),'Очистить')]"));
};

// Кнопка "Отменить"
this.getCancelButton = function() {
  return element(by.xpath("//a[@class='b-button']/span[@class='b-button__label'][contains(text(),'Отменить')]"));
};

