/**
 * @file       all-clients.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Последовательный сценарий на фильтер вкладки клиент списка обращений: "Все клиенты"
 *
 * @created    [25.09.2015] Lilia Sapurina.
 */

describe('1. Выделим обращение. После перехода на вкладку "Клиент" и выбора параметра фильтрации "Все клиенты"', function () {

  var lib = require("../common.js");
  var config = browser.params;
  var url = config.listOfReferencesUrl,
          grid,
          toolbar,
          tabs,
          list,
          client,
          radioGroup;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Grid на страницу
    grid = psGrid(by.css(psGridId));
    grid.waitReady();

    // Выделяем первое обращение
    grid.getColumn(gridFilter.number).get(0).toPsGrid().waitReady();
    grid.getColumn(gridFilter.number).get(0).click();

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();

    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();
  });

  it('значение в выпадающем списке становится "Все клиенты"', function () {
    since('значение по умолчанию не "Все клиенты", а "#{actual}"').
            expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
  });

  describe('2. После нажатия кнопки "Отмена"', function () {

    var baseUrl = browser.baseUrl;

    beforeAll(function () {
      // Нажмём клавишу "Отменить"
      lib.getCancelButton().click();
    });

    it('форма фильтра закрыта', function () {
      since('Форма фильтра не закрыта"').
              expect(list.isPresent()).toBe(false);
    });

    it('открыт список обращений', function () {
      since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
              expect(browser.getCurrentUrl()).toBe(baseUrl + url);
    });

    it('состояние списка не изменено(выделено то же обращение)', function () {

      grid.getColumn(gridFilter.number).get(0).toPsGrid().waitReady();
      // Извлечём цвет обращения в формате rgba(.,.,.,.)
      grid.getColumn(gridFilter.number).get(0).getCssValue('color').then(function (color1) {
        // Сравним с цветом второго обращения
        grid.getColumn(gridFilter.number).get(1).getCssValue('color').then(function (color2) {
            since('Обращение не было выделено').
                      expect(color1).not.toEqual(color2);
        });
      });
    });

    describe('3. Перейдём на вкладку "Клиент" и выберем параметра фильтрации "Все клиенты". После нажатия кнопки "Применить"', function () {

      beforeAll(function () {

        // Подождём загрузки формы с кнопками
        toolbar.waitReady();

        toolbar.getSearchButton().click();
        client.click();

        // Нажмём клавишу "Применить"
        lib.getApplyButton().click();
      });

      it('форма фильтра закрыта', function () {
        since('Форма фильтра не закрыта"').
                expect(list.isPresent()).toBe(false);
      });

      it('открыт список обращений', function () {
        since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                expect(browser.getCurrentUrl()).toBe(baseUrl + url);
      });

      it('состояние списка обновлено (ни одно обращение не выделено)', function () {

        grid.getColumn(gridFilter.number).get(0).toPsGrid().waitReady();
        // Извлечём цвет обращения в формате rgba(.,.,.,.)
        grid.getColumn(gridFilter.number).get(0).getCssValue('color').then(function (color1) {
          // Сравним с цветом второго обращения
          grid.getColumn(gridFilter.number).get(1).getCssValue('color').then(function (color2) {
            since('Обращение выделено').
                    expect(color1).not.toEqual(color2);
          });
        });
      });
    });
  });
});

