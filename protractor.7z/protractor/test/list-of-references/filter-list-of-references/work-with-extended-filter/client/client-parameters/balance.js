/**
 * @file       balance.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Последовательный сценарий на фильтр вкладки клиент списка обращений: "Параметры клиента": "Баланс"
 *
 * @created    [07.10.2015] Lilia Sapurina.
 */

describe('1. После открытия страницы с фильтром, нажатия кнопки "Очистить", перехода на кладку "Клиент" и установки значения фильтрации "Параметры клиента"', function () { //NOSONAR

  var lib = require("../../common.js");
  var config = browser.params;
  var url = config.listOfReferencesUrl,
          toolbar,
          list,
          tabs,
          client,
          categoryButton,
          categoryDrop,
          balance,
          radioGroup;

  // Порядковые номера фильтрующих полей
  var clientNameNum = clientParameters.clientName,
          categoryNum = clientParameters.category,
          featureNum = clientParameters.feature,
          classNum = clientParameters.class,
          statusNum = clientParameters.status,
          filialNum = clientParameters.filial,
          unionNum = clientParameters.union,
          planNum = clientParameters.plan,
          balanceNum = clientParameters.balance;

  // Фильтрующие поля
  var clientName,
          category,
          feature,
          classF,
          status,
          filial,
          union,
          plan;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();

    // Внутри компонента ps-Toolbar ищем кнопку очистки
    toolbar.getClearButton().click();
    // Внутри компонента ps-Toolbar ищем кнопку с биноклем
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    // Ищем компонент ps-List на странице
    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();

    // Устанавливаем переключатель к состояние "Параметры клиента"
    radioGroup.clickOnCaption("Параметры клиента");

    clientName = list.getTableValues().get(clientNameNum).toPsList();
    categoryButton = list.getTableValues().get(categoryNum - 1).toPsList().getDropButton();
    category = list.getTableValues().get(categoryNum - 1).toPsList();
    feature = list.getTableValues().get(featureNum).toPsList();
    classF = list.getTableValues().get(classNum).toPsList();
    status = list.getTableValues().get(statusNum).toPsList();
    filial = list.getTableValues().get(filialNum).toPsList();
    union = list.getTableValues().get(unionNum).toPsList();
    plan = list.getTableValues().get(planNum).toPsList();
    balance = list.getTableValues().get(balanceNum - 1).toPsList().getInput();

    // Откроем список категорий
    categoryButton.click();

    // Выберем BIS
    categoryDrop = psDrop(by.xpath(psDropId));
    categoryDrop.getCategoryValue(categoryValues.bis).click();
    categoryButton.waitReady();
    // Закроем список категорий
    categoryButton.click();
  });

 it('поле "Наименование клиента" разрешено', function () {
    since('поле "Наименование клиента" не разрешено').
            expect(clientName.isEnabled()).toBe(true);
  });

  it('поле "Категория" разрешено', function () {
    since('поле "Категория" не разрешено').
            expect(categoryButton.isEnabled()).toBe(true);
  });

  it('поле "Признак" разрешено', function () {
    since('поле "Признак" не разрешено').
            expect(feature.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Класс" разрешено', function () {
    since('поле "Класс" не разрешено').
            expect(classF.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Статус" разрешено', function () {
    since('поле "Статус" не разрешено').
            expect(status.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Филиал" разрешено', function () {
    since('поле "Филиал" не разрешено').
            expect(filial.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Объединение" разрешено', function () {
    since('поле "Объединение" не разрешено').
            expect(union.getDropButton().getAttribute("disabled")).toEqual(null);
  });

  it('поле "Тарифный план" разрешено', function () {
    since('поле "Тарифный план" не разрешено').
            expect(plan.isEnabled()).toBe(true);
  });

  it('поле "Баланс" разрешено', function () {
    since('поле "Баланс" не разрешено').
            expect(balance.isEnabled()).toBe(true);
  });

  describe('2. После клика на поле "Баланс"', function () { //NOSONAR

    var balloon;

    beforeAll(function () {
      balance.click();

      balloon = psBalloon(by.xpath("//div[contains(@class,'n-balloon_info')]"));
      balloon.waitReady();
    });

    it('демонстрируется balloon', function () {
        since('Balloon не демонстрируется').
                expect(balloon.isDisplayed()).toBe(true);
      });

    it('Balloon содержит текст "Допустимо вводить диапазон от", "Например"', function () {
      since('Balloon не содержит текст "Допустимо вводить диапазон от"').
          expect(balloon.getBalloonText()).toContain("Допустимо вводить диапазон от");

      since('Balloon не содержит текст "Например"').
          expect(balloon.getBalloonText()).toContain("Например");
    });

    it('Balloon закрывается при нажатии на крестик', function () {
        balloon.getBalloonCross().click();
        browser.sleep(1000);

        since('Baloon демонстрируется').
                expect(balloon.isDisplayed()).toBe(false);
      });

    it('должна быть возможность вводить корректные значения: -999999999999.00', function () {
      balance.clear().sendKeys("-999999999999.00");
      since('Значение в поле не -999999999999.00,а: #{actual}').
              expect(balance.getInputText()).toEqual("-999999999999.00");
    });

    it('должна быть возможность вводить корректные значения: 999999999999.00', function () {
      balance.clear().sendKeys("999999999999.00");
      since('Значение в поле не 999999999999.00,а: #{actual}').
              expect(balance.getInputText()).toEqual("999999999999.00");
    });

    it('при вводе невалидного значения (например: 99999999999999) появляется предупреждающий balloon c соответствующим текстом', function () {
      balance.clear().sendKeys("99999999999999");

      balloon = psBalloon(by.xpath("//div[contains(@class,'n-balloon_warning')]"));
      balloon.waitReady();

      since('Baloon не демонстрируется').
              expect(balloon.isDisplayed()).toBe(true);
      since('Baloon не содержит нужный текст,а: #{actual}').
              expect(balloon.getBalloonText()).toContain("Допустимо вводить диапазон от -9 999 999 999 999.99 до 9 999 999 999 999.99");
      });

    it('поле корректно очищается', function () {
      // Выделим значение в поле
      balance.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, "a"));
      // Очистим поле при помощи DELETE
      balance.sendKeys(protractor.Key.DELETE);
      since('Значение в поле не пусто,а: #{actual}').
              expect(balance.getInputText()).toEqual("");
    });

    it('при вводе невалидного диапазона (например, 2 - 1) выполняется попытка заменить его на валидный 2 - 10', function () {
      balance.clear().sendKeys("2 - 1");
      balance.click();
      since('Значение в поле не 2 - 10,а: #{actual}').
              expect(balance.getInputText()).toEqual("2 – 10");
    });

    it('при вводе невалидного диапазона (например, 1.01 - 0) появляется предупреждающий balloon с соответствующим текстом', function () {
      balance.clear().sendKeys("1.01 - 0");

        since('Balloon не демонстрируется').
                expect(balloon.isDisplayed()).toBe(true);
        since('Balloon не содержит нужный текст,а: #{actual}').
                expect(balloon.getBalloonText()).toContain("Допустимо вводить диапазон от -9 999 999 999 999.99 до 9 999 999 999 999.99");
      });

    it('есть возможность вводить валидный диапазон: -1.01 - -0.99', function () {
      balance.clear().sendKeys("-1.01 - -0.99");
      since('Значение в поле не -1.01 - -0.99,а: #{actual}').
              expect(balance.getInputText()).toEqual("-1.01 – -0.99");
    });

    describe('3. После ввода в поле "Баланс" значения ">0"', function () {

      beforeAll(function () {
        balance.click().clear().sendKeys(">0");
      });

      it('значение корректно отображается', function () {
        since('Значение в поле не ">0",а: #{actual}').
                expect(balance.getInputText()).toEqual(">0");
      });

      describe('4. После нажатия кнопки "Применить"', function () {

        var baseUrl = browser.baseUrl;

        beforeAll(function () {
          lib.getApplyButton().click();
        });

        it('форма списка закрыта', function () {
          since('форма не закрыта').
                  expect(list.isPresent()).toBe(false);
        });

        it('открыт список обращений', function () {
          since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                  expect(browser.getCurrentUrl()).toBe(baseUrl + url);
        });

        // Поля "Баланс" в быстром фильтре нет => Заглушка
        it('в списке отображаются только обращения с положительным балансом', function () {
          since('Неверная фильтрация списка по положительному балансу').
                  expect(true).toBe(true);
        });

        describe('5. После перехода на закладку фильтра списка обращений "Клиент"', function () {

          beforeAll(function () {
            toolbar.waitReady();
            toolbar.getSearchButton().click();
            client.click();
          });

          it('в поле выбора фильтрации отображается значение "Параметры клиента"', function () {
            since('В поле выбора фильтрации отображается не #{expected},а: #{actual}').
                    expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
          });

          it('в поле "Категория" установлено  BIS', function () {
            since('В поле выбора фильтрации отображается не BIS,а: #{actual}').
                    expect(category.getValue().getText()).toEqual("BIS");
          });

          it('значение в поле "Баланс" корректно отображается', function () {
            since('Значение в поле не ">0",а: #{actual}').
                    expect(balance.getInputText()).toEqual(">0");
          });

          it('поле "Наименование клиента" разрешено', function () {
            since('поле "Наименование клиента" не разрешено').
                    expect(clientName.isEnabled()).toBe(true);
          });

          it('поле "Категория" разрешено', function () {
            since('поле "Категория" не разрешено').
                    expect(categoryButton.isEnabled()).toBe(true);
          });

          it('поле "Признак" разрешено', function () {
            since('поле "Признак" не разрешено').
                    expect(feature.getDropButton().getAttribute("disabled")).toEqual(null);
          });

          it('поле "Класс" разрешено', function () {
            since('поле "Класс" не разрешено').
                    expect(classF.getDropButton().getAttribute("disabled")).toEqual(null);
          });

          it('поле "Статус" разрешено', function () {
            since('поле "Статус" не разрешено').
                    expect(status.getDropButton().getAttribute("disabled")).toEqual(null);
          });

          it('поле "Филиал" разрешено', function () {
            since('поле "Филиал" не разрешено').
                    expect(filial.getDropButton().getAttribute("disabled")).toEqual(null);
          });

          it('поле "Объединение" разрешено', function () {
            since('поле "Объединение" не разрешено').
                    expect(union.getDropButton().getAttribute("disabled")).toEqual(null);
          });

          it('поле "Тарифный план" разрешено', function () {
            since('поле "Тарифный план" не разрешено').
                    expect(plan.isEnabled()).toBe(true);
          });

          it('поле "Баланс" разрешено', function () {
            since('поле "Баланс" не разрешено').
                    expect(balance.isEnabled()).toBe(true);
          });

          describe('6. После установки фокуса в поле перед угловой скобкой и нажатия Backspace', function () {

            beforeAll(function () {
              balance.click();
              //Преместим фокус в поле после угловой скобки
              browser.actions().sendKeys(protractor.Key.LEFT)
                      .sendKeys(protractor.Key.LEFT)
                      .sendKeys(protractor.Key.RIGHT)
                      .sendKeys(protractor.Key.BACK_SPACE).perform();
            });

            it('угловая скобка удалена', function () {
              since('В поле "Баланс" не 0,а: #{actual}').
                      expect(balance.getInputText()).toEqual("0");
            });

            describe("7. После нажатия клавиши 'Применить'", function () {

              beforeAll(function () {
                lib.getApplyButton().click();
              });

              it('форма списка закрыта', function () {
                since('форма не закрыта').
                        expect(list.isPresent()).toBe(false);
              });

              it('открыт список обращений', function () {
                since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                        expect(browser.getCurrentUrl()).toBe(baseUrl + url);
              });

              // Поля "Баланс" в быстром фильтре нет => Заглушка
              it('в списке отображаются только обращения с нулевым балансом', function () {
                since('Неверная фильтрация списка по нулевому балансу').
                        expect(true).toBe(true);
              });

              describe("8. После перехода на закладку фильтра списка обращений 'Клиент'", function () {

                beforeAll(function () {
                  toolbar.waitReady();
                  toolbar.getSearchButton().click();
                  client.click();
                });

                it('в поле выбора фильтрации отображается значение "Параметры клиента"', function () {
                  since('В поле выбора фильтрации отображается не #{expected},а: #{actual}').
                          expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
                });

                it('в поле "Категория" установлено  BIS', function () {
                  since('В поле выбора фильтрации отображается не BIS,а: #{actual}').
                          expect(category.getValue().getText()).toEqual("BIS");
                });

                it('значение корректно отображается', function () {
                  since('Значение в поле не "0",а: #{actual}').
                          expect(balance.getInputText()).toEqual("0");
                });

                it('поле "Наименование клиента" разрешено', function () {
                  since('поле "Наименование клиента" не разрешено').
                          expect(clientName.isEnabled()).toBe(true);
                });

                it('поле "Категория" разрешено', function () {
                  since('поле "Категория" не разрешено').
                          expect(categoryButton.isEnabled()).toBe(true);
                });

                it('поле "Признак" разрешено', function () {
                  since('поле "Признак" не разрешено').
                          expect(feature.getDropButton().getAttribute("disabled")).toEqual(null);
                });

                it('поле "Класс" разрешено', function () {
                  since('поле "Класс" не разрешено').
                          expect(classF.getDropButton().getAttribute("disabled")).toEqual(null);
                });

                it('поле "Статус" разрешено', function () {
                  since('поле "Статус" не разрешено').
                          expect(status.getDropButton().getAttribute("disabled")).toEqual(null);
                });

                it('поле "Филиал" разрешено', function () {
                  since('поле "Филиал" не разрешено').
                          expect(filial.getDropButton().getAttribute("disabled")).toEqual(null);
                });

                it('поле "Объединение" разрешено', function () {
                  since('поле "Объединение" не разрешено').
                          expect(union.getDropButton().getAttribute("disabled")).toEqual(null);
                });

                it('поле "Тарифный план" разрешено', function () {
                  since('поле "Тарифный план" не разрешено').
                          expect(plan.isEnabled()).toBe(true);
                });

                it('поле "Баланс" разрешено', function () {
                  since('поле "Баланс" не разрешено').
                          expect(balance.isEnabled()).toBe(true);
                });

                describe('9. После последовательной установки значений "Выбранный клиент" и "Параметры клиента" в поле "Выбор способа фильтрации"', function () {

                  beforeAll(function () {
                    radioGroup.waitReady();
                    // Выберем значение в поле способа фильтрации "Выбранный клиент"
                    radioGroup.clickOnCaption("Выбранный клиент");
                    // Выберем значение в поле способа фильтрации "Параметры клиента"
                    radioGroup.clickOnCaption("Параметры клиента");
                  });

                  it('поле "Категория" пустое', function () {
                    since('поле "Категория" не пустое, а: #{actual}').
                            expect(category.getValue().isPresent()).toBe(false);
                  });

                  it('поле "Категория" разрешено', function () {
                    since('поле "Категория" не разрешено').
                            expect(categoryButton.isEnabled()).toBe(true);
                  });

                  it('поле "Баланс" запрещено', function () {
                    since('поле "Баланс" разрешено').
                            expect(balance.isEnabled()).toBe(false);
                  });

                  describe('10. После установки значения "BIS"  в поле "Категория" и "< отрицательный дробный баланс из обращения" в поле "Баланс"', function () {

                    beforeAll(function () {
                      // Выберем значение в поле способа фильтрации "Параметры клиента"
                      radioGroup.clickOnCaption("Параметры клиента");
                      browser.sleep(1000);
                      // Откроем выпадающий список категории
                      categoryButton.click();
                      // Выберем BIS
                      browser.actions().sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.SPACE).perform();
                      categoryButton.click();
                      balance.clear();
                      balance.click().sendKeys('< -69.75');
                    });

                    it('значение в поле отображается корректно', function () {
                      since('Значение в поле не #{expected},а: #{actual}').
                              expect(balance.getInputText()).toEqual("<-69.75");
                    });

                    describe("11. После выделения угловой скобки и нажатия кнопки Delete", function () {

                      beforeAll(function () {
                        // Пока не известно нужно ли поле быстрого фильтра "Баланс": Заглушка
                        balance.click();
                        balance.sendKeys(protractor.Key.HOME);
                        balance.sendKeys(protractor.Key.DELETE);
                      });

                      it('значение в поле отображается корректно', function () {
                        since('Значение в поле не #{expected},а: #{actual}').
                                expect(balance.getInputText()).toEqual("-69.75");
                      });

                      describe("12. После ввода перед заданным значением отрицательного значения, меньшего значения в обращении", function () {

                        beforeAll(function () {
                          // Пока не известно нужно ли поле быстрого фильтра "Баланс": Заглушка
                          balance.click();
                          balance.sendKeys(protractor.Key.HOME);
                          balance.sendKeys('-100.00 -');
                        });

                        it('отображается введённый диапазон', function () {
                          since('Значение в поле не #{expected},а: #{actual}').
                                  expect(balance.getInputText()).toEqual("-100.00 – -69.75");
                        });

                        describe('13. После нажатия кнопки "Применить"', function () {

                          beforeAll(function () {
                            lib.getApplyButton().click();
                          });

                          it('форма списка закрыта', function () {
                            since('форма не закрыта').
                                    expect(list.isPresent()).toBe(false);
                          });

                          it('открыт список обращений', function () {
                            since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                                    expect(browser.getCurrentUrl()).toBe(baseUrl + url);
                          });

                          // Поля "Баланс" в быстром фильтре нет => Заглушка
                          it('в списке отображаются только обращения с положительным балансом', function () {
                            since('Неверная фильтрация списка по положительному балансу').
                                    expect(true).toBe(true);
                          });

                          describe('14. После перехода на закладку фильтра списка обращений "Клиент"', function () {

                            beforeAll(function () {
                              toolbar.waitReady();
                              toolbar.getSearchButton().click();
                              client.click();
                            });

                            it('в поле выбора фильтрации отображается значение "Параметры клиента"', function () {
                              since('В поле выбора фильтрации отображается не #{expected},а: #{actual}').
                                      expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
                            });

                            it('в поле "Категория" установлено  BIS', function () {
                              since('В поле выбора фильтрации отображается не BIS,а: #{actual}').
                                      expect(category.getValue().getText()).toEqual("BIS");
                            });

                            it('диапазон в поле "Баланс" корректно отображается', function () {
                              since('Значение в поле не "-100.00 – -69.75",а: #{actual}').
                                      expect(balance.getInputText()).toEqual("-100.00 – -69.75");
                            });

                            it('поле "Наименование клиента" разрешено', function () {
                              since('поле "Наименование клиента" не разрешено').
                                      expect(clientName.isEnabled()).toBe(true);
                            });

                            it('поле "Категория" разрешено', function () {
                              since('поле "Категория" не разрешено').
                                      expect(categoryButton.isEnabled()).toBe(true);
                            });

                            it('поле "Признак" разрешено', function () {
                              since('поле "Признак" не разрешено').
                                      expect(feature.getDropButton().getAttribute("disabled")).toEqual(null);
                            });

                            it('поле "Класс" разрешено', function () {
                              since('поле "Класс" не разрешено').
                                      expect(classF.getDropButton().getAttribute("disabled")).toEqual(null);
                            });

                            it('поле "Статус" разрешено', function () {
                              since('поле "Статус" не разрешено').
                                      expect(status.getDropButton().getAttribute("disabled")).toEqual(null);
                            });

                            it('поле "Филиал" разрешено', function () {
                              since('поле "Филиал" не разрешено').
                                      expect(filial.getDropButton().getAttribute("disabled")).toEqual(null);
                            });

                            it('поле "Объединение" разрешено', function () {
                              since('поле "Объединение" не разрешено').
                                      expect(union.getDropButton().getAttribute("disabled")).toEqual(null);
                            });

                            it('поле "Тарифный план" разрешено', function () {
                              since('поле "Тарифный план" не разрешено').
                                      expect(plan.isEnabled()).toBe(true);
                            });

                            it('поле "Баланс" разрешено', function () {
                              since('поле "Баланс" не разрешено').
                                      expect(balance.isEnabled()).toBe(true);
                            });

                            describe('15. После изменения значения в поле "Баланс" и установки в поле "Категория" только значения CMS CUSTOMER', function () {

                              beforeAll(function () {
                                categoryButton.click();
                                balance.clear();
                                balance.sendKeys(5);
                                // Уберём BIS, поставим CMS_CUSTOMER
                                browser.actions().sendKeys(protractor.Key.SPACE).sendKeys(protractor.Key.DOWN).sendKeys(protractor.Key.SPACE).perform();
                              });

                              it('поле "Баланс" запрещено', function () {
                                since('поле "Баланс" разрешено').
                                        expect(balance.isEnabled()).toBe(false);
                              });

                              it('значение в поле "Баланс" корректно отображается', function () {
                                since('Значение в поле не "5",а: #{actual}').
                                        expect(balance.getInputText()).toEqual("5");
                              });

                              describe('16. После нажатия кнопки "Отменить"', function () {

                                beforeAll(function () {
                                  lib.getCancelButton().click();
                                });

                                it('форма списка закрыта', function () {
                                  since('форма не закрыта').
                                          expect(list.isPresent()).toBe(false);
                                });

                                it('открыт список обращений', function () {
                                  since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                                          expect(browser.getCurrentUrl()).toBe(baseUrl + url);
                                });

                                // Поля "Баланс" в быстром фильтре нет => Заглушка
                                it('состояние списка не изменено (значения из отрицательного диапазона)', function () {
                                  since('Неверная фильтрация списка по отрицательному диапазону').
                                          expect(true).toBe(true);
                                });

                                describe('17. После перехода на закладку фильтра списка обращений "Клиент"', function () {

                                  beforeAll(function () {
                                    toolbar.waitReady();
                                    toolbar.getSearchButton().click();
                                    client.click();
                                  });

                                  it('поле "Баланс" запрещено', function () {
                                    since('поле "Баланс" разрешено').
                                            expect(balance.isEnabled()).toBe(false);
                                  });

                                  it('значение в поле "Баланс" корректно отображается', function () {
                                    since('Значение в поле не "5",а: #{actual}').
                                            expect(balance.getInputText()).toEqual("5");
                                  });
                                });
                              });
                            });
                          });
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});
