/**
 * @file       choose-filter-method.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview Последовательный сценарий на фильтр вкладки клиент списка обращений: "Выбор способа фильтрации"
 *
 * @created    [23.09.2015] Lilia Sapurina.
 */


describe('1. После перехода на вкладку "Клиент"', function () {

  var lib = require("../common.js");
  var config = browser.params;
  var url = config.listOfReferencesUrl,
          toolbar,
          tabs,
          list,
          client,
          contacts,
          treatment,
          radioGroup;

  beforeAll(function () {

    // Загружаем страницу списка обращений
    load(url, "list-of-references");

    // Ищем компонент ps-Toolbar на странице
    toolbar = psToolbar(by.css(psToolbarId));
    toolbar.waitReady();
    // Внутри компонента ps-Toolbar ищем кнопку обновления
    toolbar.getSearchButton().click();

    // Ищем компонент ps-Tabs на странице
    tabs = psTabs(by.xpath(psTabsId));
    tabs.waitReady();

    // Кликнем на вкладку "Клиент"
    client = tabs.getTabByName("Клиент");
    client.click();

    // Обратимся к соседним вкладкам - "Контакты" и "Обработка", чтобы понять, что соседние вкладки визуально отличаются
    contacts = tabs.getTabByName("Контакты");
    treatment = tabs.getTabByName("Обработка");

    list = psList(by.xpath(psListClientId));
    list.waitReady();

    radioGroup = psRadioGroup(by.xpath("//div[contains(@class,'n-radio-group')]"));
    radioGroup.waitReady();
  });

  it('она выбрана(отличается от остальных)', function () {

    // Извлечём цвет вкладки в формате rgba(.,.,.,.)
    client.getCssValue('color').then(function (color1) {

      // Сравним цвета вкладок "Контакты" и "Клиент"
      contacts.getCssValue('color').then(function (color2) {
        since('Вкладка не отличается от вкладки "Контакты"').
                expect(color1).not.toEqual(color2);
      });

      // Сравним цвета вкладок "Клиент" и "Обработка"
      treatment.getCssValue('color').then(function (color2) {
        since('Вкладка не отличается от вкладки "Обработка"').
                expect(color1).not.toEqual(color2);
      });
    });
  });

  it('заголовок группы "Способ фильтрации" ', function () {
    since('Заголовок группы не "Способ фильтрации", а "#{actual}"').
            expect(list.getTopBarLabel().getText()).toEqual("Способ фильтрации");
  });

  it('расположение переключателей горизонтально ', function () {
    since('Переключатели не расположены горизонтально "#{actual}" "#{expected}"').
            expect(radioGroup.getCaptionWithText("Все клиенты").getX()).toBeLessThan(radioGroup.getCaptionWithText("Выбранный клиент").getX());
    since('Переключатели не расположены горизонтально "#{actual}" "#{expected}"').
            expect(radioGroup.getCaptionWithText("Выбранный клиент").getX()).toBeLessThan(radioGroup.getCaptionWithText("Выбранные абоненты").getX());
    since('Переключатели не расположены горизонтально "#{actual}" "#{expected}"').
            expect(radioGroup.getCaptionWithText("Выбранные абоненты").getX()).toBeLessThan(radioGroup.getCaptionWithText("Параметры клиента").getX());
  });

  it('присутствует элемент группы: "Все клиенты"', function () {
    since('Элемент группы "Все клиенты" не представлен, а "#{actual}"').
            expect(radioGroup.getCaptionWithText("Все клиенты").isPresent()).toBe(true);
  });

  it('присутствует элемент группы: "Выбранный клиент"', function () {
    since('Элемент группы "Выбранный клиент" не представлен, а "#{actual}"').
            expect(radioGroup.getCaptionWithText("Выбранный клиент").isPresent()).toBe(true);
  });

  it('присутствует элемент группы: "Выбранные абоненты"', function () {
    since('Элемент группы "Выбранные абоненты" не представлен, а "#{actual}"').
            expect(radioGroup.getCaptionWithText("Выбранные абоненты").isPresent()).toBe(true);
  });

  it('присутствует элемент группы: "Параметры клиента"', function () {
    since('Элемент группы "Параметры клиента" не представлен, а "#{actual}"').
            expect(radioGroup.getCaptionWithText("Параметры клиента").isPresent()).toBe(true);
  });

  it('выбранный элемент: "Все клиенты"', function () {
    since('Выбранный элемент не "Все клиенты", а "#{actual}"').
            expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
  });

  describe('2. После клика по свободному месту формы (вне переключателей)', function () {

    var indent;

    beforeAll(function () {
      // Отступим на indent пикселей по обеим осям от элемента и кликнем мышью
      indent = Math.floor(Math.random()*20) + 80;
      browser.actions().mouseMove(radioGroup, {x: indent, y: indent}).click();
    });

    it('выбранный элемент: "Все клиенты"', function () {
      since('Выбранный элемент не "Все клиенты", а "#{actual}"').
              expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
    });

  describe('3. После нажатия на способ фильтрации "Параметры клиента"', function () {

    // Порядковые номера фильтрующих полей
    var clientNameNum = clientParameters.clientName,
            categoryNum = clientParameters.category,
            featureNum = clientParameters.feature,
            classNum = clientParameters.class,
            statusNum = clientParameters.status,
            filialNum = clientParameters.filial,
            unionNum = clientParameters.union,
            planNum = clientParameters.plan,
            balanceNum = clientParameters.balance;

    // Фильтрующие поля
    var clientName,
            category,
            feature,
            classF,
            status,
            filial,
            union,
            plan,
            balance;

    beforeAll(function () {
      radioGroup.clickOnCaption("Параметры клиента");

      clientName = list.getTableLabeles().get(clientNameNum);
      category = list.getTableLabeles().get(categoryNum);
      feature = list.getTableLabeles().get(featureNum);
      classF = list.getTableLabeles().get(classNum);
      status = list.getTableLabeles().get(statusNum);
      filial = list.getTableLabeles().get(filialNum);
      union = list.getTableLabeles().get(unionNum);
      plan = list.getTableLabeles().get(planNum);
      balance = list.getTableLabeles().get(balanceNum);
    });

    it('выбранный элемент: "Параметры клиента"', function () {
      since('Выбранный элемент не "Параметры клиента", а "#{actual}"').
              expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
    });

    it('отображается параметр фильтрации "Наименование клиента"', function () {
      since('Отображается параметр фильтрации не "Наименование клиента", а "#{actual}"').
              expect(clientName.getText()).toEqual("Наименование клиента");
    });

    it('отображается параметр фильтрации "Категория"', function () {
      since('Отображается параметр фильтрации не "Категория", а "#{actual}"').
              expect(category.getText()).toEqual("Категория");
    });

    it('отображается параметр фильтрации "Признак"', function () {
      since('Отображается параметр фильтрации не "Признак", а "#{actual}"').
              expect(feature.getText()).toEqual("Признак");
    });

    it('отображается параметр фильтрации "Класс"', function () {
      since('Отображается параметр фильтрации не "Класс", а "#{actual}"').
              expect(classF.getText()).toEqual("Класс");
    });

    it('отображается параметр фильтрации "Статус"', function () {
      since('Отображается параметр фильтрации не "Статус", а "#{actual}"').
              expect(status.getText()).toEqual("Статус");
    });

    it('отображается параметр фильтрации "Филиал"', function () {
      since('Отображается параметр фильтрации не "Филиал", а "#{actual}"').
              expect(filial.getText()).toEqual("Филиал");
    });

    it('отображается параметр фильтрации "Объединение"', function () {
      since('Отображается параметр фильтрации не "Объединение", а "#{actual}"').
              expect(union.getText()).toEqual("Объединение");
    });

    it('отображается параметр фильтрации "Тарифный план"', function () {
      since('Отображается параметр фильтрации не "Тарифный план", а "#{actual}"').
              expect(plan.getText()).toEqual("Тарифный план");
    });

    it('отображается параметр фильтрации "Баланс"', function () {
      since('Отображается параметр фильтрации не "Баланс", а "#{actual}"').
              expect(balance.getText()).toEqual("Баланс");
    });

    describe('4. После нажатия способ фильтрации "Выбранный клиент"', function () {

      // Порядковые номера фильтрующих полей
      var clientNum = clientParameters.client,
              abonentsNum = clientParameters.abonents;

      // Фильтрующие поля
      var clientF,
          abonents;

      beforeAll(function () {
        radioGroup.clickOnCaption("Выбранный клиент");

        clientF = list.getTableLabeles().get(clientNum);
        abonents = list.getTableLabeles().get(abonentsNum);
      });

      it('выбранный элемент: "Выбранный клиент"', function () {
        since('Выбранный элемент не "Выбранный клиент", а "#{actual}"').
                expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранный клиент");
      });

      it('отображается параметр фильтрации "Клиент"', function () {
        since('Отображается параметр фильтрации не "Клиент", а "#{actual}"').
                expect(clientF.getText()).toEqual("Клиент");
      });

      it('отображается параметр фильтрации "Абоненты"', function () {
        since('Отображается параметр фильтрации не "Абоненты", а "#{actual}"').
                expect(abonents.getText()).toEqual("Абоненты");
      });

      it('заголовки отображаются полностью', function () {
        since('Заголовки не отображаются полностью; Размер параметра "Клиент": "#{actual}"').
                expect(clientF.toPsList().getWidth()).toBeGreaterThan(139);
        since('Заголовки не отображаются полностью; Размер параметра "Абоненты": "#{actual}"').
                expect(abonents.toPsList().getWidth()).toBeGreaterThan(139);
      });

      describe('5. После нажатия способ фильтрации "Выбранные абоненты"', function () {

        beforeAll(function () {
          radioGroup.clickOnCaption("Выбранные абоненты");
        });

        it('выбранный элемент: "Выбранные абоненты"', function () {
          since('Выбранный элемент не "Выбранные абоненты", а "#{actual}"').
                  expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранные абоненты");
        });

        it('отображается параметр фильтрации "Номера абонентов"', function () {
          since('Отображается параметр фильтрации не "Номера абонентов", а "#{actual}"').
                  expect(clientF.getText()).toEqual("Номера абонентов");
        });

        describe('6. После нажатия способ фильтрации "Все клиенты"', function () {

          beforeAll(function () {
            radioGroup.clickOnCaption("Все клиенты");
          });

          it('выбранный элемент: "Все клиенты"', function () {
            since('Выбранный элемент не "Все клиенты", а "#{actual}"').
                    expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
          });

          it('дополнительные параметры фильтрации не отображаются', function () {
            since('Отображается "#{actual}" дополнительных параметров фильтрации').
                    expect(list.getTableLabeles().count()).toEqual(1);
          });

          describe('7. После последовательного переключения выбора способа фильтрации при помощи клавиатуры', function () {


            beforeAll(function () {
              browser.actions().sendKeys(protractor.Key.RIGHT).perform();
            });

            it('выбранный элемент: "Выбранный клиент"', function () {
              since('Выбранный элемент не "Выбранный клиент", а "#{actual}"').
                      expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранный клиент");
            });

            it('отображается параметр фильтрации "Клиент"', function () {
              since('Отображается параметр фильтрации не "Клиент", а "#{actual}"').
                      expect(clientF.getText()).toEqual("Клиент");
            });

            it('отображается параметр фильтрации "Абоненты"', function () {
              since('Отображается параметр фильтрации не "Абоненты", а "#{actual}"').
                      expect(abonents.getText()).toEqual("Абоненты");
            });

            it('выбранный элемент: "Выбранные абоненты"', function () {

              browser.actions().sendKeys(protractor.Key.RIGHT).perform();

              since('Выбранный элемент не "Выбранные абоненты", а "#{actual}"').
                      expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранные абоненты");
            });

            it('отображается параметр фильтрации "Номера абонентов"', function () {
              since('Отображается параметр фильтрации не "Номера абонентов", а "#{actual}"').
                      expect(clientF.getText()).toEqual("Номера абонентов");
            });

            it('выбранный элемент: "Параметры клиента"', function () {

              browser.actions().sendKeys(protractor.Key.RIGHT).perform();

              since('Выбранный элемент не "Параметры клиента", а "#{actual}"').
                      expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Параметры клиента");
            });

            it('отображается параметр фильтрации "Наименование клиента"', function () {
              since('Отображается параметр фильтрации не "Наименование клиента", а "#{actual}"').
                      expect(clientName.getText()).toEqual("Наименование клиента");
            });

            it('отображается параметр фильтрации "Категория"', function () {
              since('Отображается параметр фильтрации не "Категория", а "#{actual}"').
                      expect(category.getText()).toEqual("Категория");
            });

            it('отображается параметр фильтрации "Признак"', function () {
              since('Отображается параметр фильтрации не "Признак", а "#{actual}"').
                      expect(feature.getText()).toEqual("Признак");
            });

            it('отображается параметр фильтрации "Класс"', function () {
              since('Отображается параметр фильтрации не "Класс", а "#{actual}"').
                      expect(classF.getText()).toEqual("Класс");
            });

            it('отображается параметр фильтрации "Статус"', function () {
              since('Отображается параметр фильтрации не "Статус", а "#{actual}"').
                      expect(status.getText()).toEqual("Статус");
            });

            it('отображается параметр фильтрации "Филиал"', function () {
              since('Отображается параметр фильтрации не "Филиал", а "#{actual}"').
                      expect(filial.getText()).toEqual("Филиал");
            });

            it('отображается параметр фильтрации "Объединение"', function () {
              since('Отображается параметр фильтрации не "Объединение", а "#{actual}"').
                      expect(union.getText()).toEqual("Объединение");
            });

            it('отображается параметр фильтрации "Тарифный план"', function () {
              since('Отображается параметр фильтрации не "Тарифный план", а "#{actual}"').
                      expect(plan.getText()).toEqual("Тарифный план");
            });

            it('отображается параметр фильтрации "Баланс"', function () {
              since('Отображается параметр фильтрации не "Баланс", а "#{actual}"').
                      expect(balance.getText()).toEqual("Баланс");
            });

            it('выбранный элемент: "Выбранные абоненты"', function () {

              browser.actions().sendKeys(protractor.Key.LEFT).perform();

              since('Выбранный элемент не "Выбранные абоненты", а "#{actual}"').
                      expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранные абоненты");
            });

            it('отображается параметр фильтрации "Номера абонентов"', function () {
              since('Отображается параметр фильтрации не "Номера абонентов", а "#{actual}"').
                      expect(clientF.getText()).toEqual("Номера абонентов");
            });

            it('выбранный элемент: "Выбранный клиент"', function () {

              browser.actions().sendKeys(protractor.Key.LEFT).perform();

              since('Выбранный элемент не "Выбранный клиент", а "#{actual}"').
                      expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Выбранный клиент");
            });

            it('отображается параметр фильтрации "Клиент"', function () {
              since('Отображается параметр фильтрации не "Клиент", а "#{actual}"').
                      expect(clientF.getText()).toEqual("Клиент");
            });

            it('отображается параметр фильтрации "Абоненты"', function () {
              since('Отображается параметр фильтрации не "Абоненты", а "#{actual}"').
                      expect(abonents.getText()).toEqual("Абоненты");
            });

            it('выбранный элемент: "Все клиенты"', function () {

              browser.actions().sendKeys(protractor.Key.LEFT).perform();

              since('Выбранный элемент не "Все клиенты", а "#{actual}"').
                      expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
            });

            it('дополнительные параметры фильтрации не отображаются', function () {
              since('Отображается "#{actual}" дополнительных параметров фильтрации').
                      expect(list.getTableLabeles().count()).toEqual(1);
            });

            describe('8. После нажатия клавиши "Очистить"', function () {

              beforeAll(function () {
                lib.getClearButton();
              });

              it('выбранный элемент: "Все клиенты"', function () {
                since('Выбранный элемент не "Все клиенты", а "#{actual}"').
                        expect(radioGroup.getRadioButtonWithGreenBall().getText()).toEqual("Все клиенты");
              });

              it('фокус не в поле (значение не выделено)', function () {
                since('Значение выделено').
                        expect(true).toBe(true);
              });

              it('дополнительные параметры фильтрации не отображаются', function () {
                since('Отображается "#{actual}" дополнительных параметров фильтрации').
                        expect(list.getTableLabeles().count()).toEqual(1);
              });

              describe('9. После нажатия клавиши "Применить"', function () {

                var baseUrl = browser.baseUrl;

                beforeAll(function () {
                  lib.getApplyButton().click();
                });

                it('открыт список обращений', function () {
                  since('Список обращений не открыт. Сслыка не #{expected},а: #{actual}').
                    expect(browser.getCurrentUrl()).toBe(baseUrl + url);
                });
              });
            });
          });
        });
      });
    });
  });
 });
});


