﻿/**
 * @file       run_all_tests_conf.js
 * @package
 * @copyright  Copyright (c) CJSC PETER-SERVICE, 2015.
 * @author     Lilia Sapurina Lilia.Sapurina@billing.ru.
 * @fileoverview
 *
 * @created    [06.08.2015] Lilia Sapurina.
 */

global.globalConf = require('..//config/global.js');
require('..//plugin/index.js');

// Присваеваем полученный конфиг текущему
exports.config = {
  seleniumAddress: globalConf.seleniumAddress,

  baseUrl: globalConf.baseUrl,

  specs: ['../resource/marina/SBMS-CreateCustomer-CopyNameAndContact.js'],

  exclude: [globalConf.path_to_resource + 'ps-grid/*.js',
            globalConf.path_to_resource + 'ps-grid-column-filter-range/*.js',
            globalConf.path_to_test + 'ps-grid-column-filter-range/*.js'
  ],

  plugins: globalConf.plugins,

  capabilities: globalConf.capabilities,

  framework: globalConf.framework,

  params: {

    'listOfReferencesUrl': 'sbms/shell.html?shell_login=CMS_HAS&shell_password=qwerty&shell_modus=t',
    'psTextFieldUrl': 'ng-components/examples/ps-text-field.html',
    'psListUrl': 'ng-components/examples/ps-list.html',
    'psDateTimePickerUrl': 'ng-components/examples/ps-date-time-picker.html',
    'psColumnFilterRangeUrl': 'ng-components/examples/ps-grid-column-filter-range.html',
    'psGridUrl': 'ng-components/examples/ps-grid.html'

  },

  onPrepare: globalConf.onPrepare

};